import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Users,
  UserPlus,
  Search,
  Filter,
  MoreHorizontal,
  Mail,
  Phone,
  MessageSquare,
  Video,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Target,
  CheckCircle,
  Clock,
  AlertTriangle,
  Star,
  Calendar,
  FileText,
  BarChart3,
  Settings,
  MapPin,
  Globe,
  Briefcase,
  Edit,
  Eye,
  Plus,
  Download,
  Database,
  Activity,
  Building,
  ShoppingCart,
  Package,
  Truck,
  Award,
  Flag,
  Heart,
  ArrowRight,
  PieChart,
  LineChart,
  Zap,
  RefreshCw,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Layout } from "../components/Layout";
import { COMPANY_INFO, TARGET_MARKETS, PRODUCTS } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

// Sales pipeline stages
const pipelineStages = [
  { name: "Lead", color: "bg-gray-500", count: 0 },
  { name: "Qualified", color: "bg-blue-500", count: 0 },
  { name: "Proposal", color: "bg-yellow-500", count: 0 },
  { name: "Negotiation", color: "bg-orange-500", count: 0 },
  { name: "Won", color: "bg-green-500", count: 0 },
];

export default function CRM() {
  const [selectedView, setSelectedView] = useState("customers");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterMarket, setFilterMarket] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const handleAddCustomer = () => {
    alert(
      "👤 Add New Customer\n\nCreate customer profile:\n\n• Company information\n• Contact details\n• Market region\n• Product interests\n• Credit terms\n• Compliance requirements\n• Purchase history\n• Communication preferences\n\nIntegrated with export workflow",
    );
  };

  const handleAddLead = () => {
    alert(
      "🎯 Add New Lead\n\nCreate sales lead:\n\n• Lead source and type\n• Contact information\n• Market interest\n• Product requirements\n• Budget estimation\n• Timeline expectations\n• Qualification status\n• Follow-up schedule\n\nAutomatic nurturing workflow",
    );
  };

  const handleSetupCRM = () => {
    alert(
      "⚙️ Setup CRM System\n\nGet started with:\n\n• Customer data import\n• Sales pipeline configuration\n• Lead scoring rules\n• Market segmentation\n• Integration with exports\n• Automated workflows\n• Reporting dashboards\n• Team access permissions",
    );
  };

  const handleImportCustomers = () => {
    alert(
      "📂 Import Customer Data\n\nSupported formats:\n\n• Excel/CSV files\n• Contact databases\n• Email platforms\n• Existing CRM systems\n• Trade directories\n\nFeatures:\n• Data validation\n• Duplicate detection\n• Field mapping\n• Bulk operations\n• Data cleansing",
    );
  };

  const renderCustomersView = () => (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Building className="mr-2 h-5 w-5 text-blue-600" />
              Customer Database
            </CardTitle>
            <CardDescription>
              Manage your spice export customers worldwide
            </CardDescription>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleImportCustomers}>
              <Download className="mr-2 h-4 w-4" />
              Import
            </Button>
            <Button onClick={handleAddCustomer}>
              <UserPlus className="mr-2 h-4 w-4" />
              Add Customer
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Empty State for Customers */}
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Building className="h-12 w-12 text-blue-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No Customers Added Yet
          </h3>
          <p className="text-gray-600 mb-8 max-w-md mx-auto">
            Start building your customer database by adding importers,
            distributors, and buyers from your target markets. Track orders,
            preferences, and communication history.
          </p>

          <div className="space-y-4">
            <Button
              className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3"
              onClick={handleAddCustomer}
            >
              <UserPlus className="mr-2 h-5 w-5" />
              Add Your First Customer
            </Button>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 max-w-4xl mx-auto mt-8">
              {TARGET_MARKETS.map((market) => (
                <div
                  key={market.id}
                  className="bg-gray-50 p-4 rounded-lg text-center border hover:bg-gray-100 cursor-pointer transition-colors"
                  onClick={() =>
                    alert(
                      `${market.flag} ${market.name} Market\n\nTarget customer types:\n• Spice importers\n• Food distributors\n• Retail chains\n• Restaurant suppliers\n• Wholesale traders\n\nKey products: ${market.keyProducts.join(", ")}\nMarket share: ${market.exportVolume}`,
                    )
                  }
                >
                  <span className="text-2xl mb-2 block">{market.flag}</span>
                  <h4 className="font-semibold text-gray-900 mb-1">
                    {market.name}
                  </h4>
                  <p className="text-sm text-gray-600">0 customers</p>
                  <Badge variant="outline" className="mt-2">
                    {market.exportVolume}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const renderLeadsView = () => (
    <div className="space-y-6">
      {/* Lead Generation Dashboard */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5 text-yellow-600" />
                Lead Generation & Engagement
              </CardTitle>
              <CardDescription>
                Multi-channel lead generation for spice exports
              </CardDescription>
            </div>
            <Button onClick={handleAddLead}>
              <Plus className="mr-2 h-4 w-4" />
              Add Lead
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Lead Generation Channels */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div
              className="bg-blue-50 p-4 rounded-lg text-center hover:bg-blue-100 cursor-pointer transition-colors"
              onClick={() =>
                alert(
                  "🌐 Digital Marketing\n\nOnline lead generation:\n\n• Google Ads for spice importers\n• LinkedIn B2B campaigns\n• Industry forum participation\n• SEO-optimized website\n• Content marketing (spice guides)\n• Email marketing campaigns\n• Social media presence\n• Webinar hosting\n\nTarget keywords: spice importers, Kerala spices, export quality",
                )
              }
            >
              <Globe className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h4 className="font-semibold text-blue-900 mb-1">
                Digital Marketing
              </h4>
              <p className="text-sm text-blue-700">0 leads generated</p>
              <Badge className="mt-2" variant="outline">
                Setup
              </Badge>
            </div>

            <div
              className="bg-green-50 p-4 rounded-lg text-center hover:bg-green-100 cursor-pointer transition-colors"
              onClick={() =>
                alert(
                  "🤝 Trade Shows\n\nEvent-based lead generation:\n\n• Gulfood Dubai (UAE)\n• SIAL Paris (Europe)\n• Anuga Cologne (Germany)\n• PLMA Amsterdam (Private Label)\n• World of Food India\n• Spice India Exhibition\n• Food & Hotel Asia\n• Africa Food Manufacturing\n\nBooth strategy, sample distribution, lead capture forms",
                )
              }
            >
              <Award className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <h4 className="font-semibold text-green-900 mb-1">Trade Shows</h4>
              <p className="text-sm text-green-700">0 events planned</p>
              <Badge className="mt-2" variant="outline">
                Plan
              </Badge>
            </div>

            <div
              className="bg-purple-50 p-4 rounded-lg text-center hover:bg-purple-100 cursor-pointer transition-colors"
              onClick={() =>
                alert(
                  "📞 Cold Outreach\n\nDirect prospecting:\n\n• Import/export directories\n• LinkedIn sales navigator\n• Industry databases\n• Government trade databases\n• Company research tools\n• Email finding tools\n• Phone prospecting\n• Personalized messaging\n\nTarget: Spice importers, food distributors, retail chains",
                )
              }
            >
              <Phone className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <h4 className="font-semibold text-purple-900 mb-1">
                Cold Outreach
              </h4>
              <p className="text-sm text-purple-700">0 campaigns active</p>
              <Badge className="mt-2" variant="outline">
                Start
              </Badge>
            </div>

            <div
              className="bg-orange-50 p-4 rounded-lg text-center hover:bg-orange-100 cursor-pointer transition-colors"
              onClick={() =>
                alert(
                  "🔗 Referrals\n\nNetwork-based leads:\n\n• Customer referral program\n• Partner network activation\n• Industry connections\n• Chamber of commerce\n• Spice board networks\n• Existing customer introductions\n• Supplier recommendations\n• Government trade contacts\n\nIncentivize successful referrals",
                )
              }
            >
              <Heart className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <h4 className="font-semibold text-orange-900 mb-1">Referrals</h4>
              <p className="text-sm text-orange-700">0 referrals tracked</p>
              <Badge className="mt-2" variant="outline">
                Activate
              </Badge>
            </div>
          </div>

          {/* Lead Engagement Strategies */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Lead Engagement Strategies
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div
                className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() =>
                  alert(
                    "📦 Sample Program\n\nProduct sampling strategy:\n\n• Free sample kits (50g each spice)\n• Premium packaging with branding\n• Product information sheets\n• Cooking recipe suggestions\n• Quality certificates included\n• Follow-up questionnaire\n• Feedback collection\n• Order conversion tracking\n\nSample cost: ₹500 per kit, High conversion rate",
                  )
                }
              >
                <Package className="h-6 w-6 text-blue-600 mb-2" />
                <h4 className="font-medium text-gray-900">Sample Program</h4>
                <p className="text-sm text-gray-600">
                  Send premium spice samples to qualified leads
                </p>
                <Badge className="mt-2" variant="secondary">
                  0 samples sent
                </Badge>
              </div>

              <div
                className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() =>
                  alert(
                    "📧 Email Sequences\n\nAutomated email nurturing:\n\n• Welcome series (5 emails)\n• Educational content (spice benefits)\n• Market insights and trends\n�� Recipe and usage guides\n• Success stories and testimonials\n• Price lists and catalogs\n• Quality certifications\n• Follow-up reminders\n\nPersonalized by market region and interests",
                  )
                }
              >
                <Mail className="h-6 w-6 text-green-600 mb-2" />
                <h4 className="font-medium text-gray-900">Email Sequences</h4>
                <p className="text-sm text-gray-600">
                  Automated nurturing campaigns
                </p>
                <Badge className="mt-2" variant="secondary">
                  0 sequences active
                </Badge>
              </div>

              <div
                className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() =>
                  alert(
                    "🎥 Content Marketing\n\nEducational content strategy:\n\n• Spice origin stories and videos\n• Quality testing demonstrations\n• Harvesting and processing tours\n• Cooking tutorials and recipes\n• Health benefits content\n• Market trend reports\n• Webinar series\n• Case studies\n\nBuild trust and expertise positioning",
                  )
                }
              >
                <Video className="h-6 w-6 text-purple-600 mb-2" />
                <h4 className="font-medium text-gray-900">Content Marketing</h4>
                <p className="text-sm text-gray-600">
                  Educational content and webinars
                </p>
                <Badge className="mt-2" variant="secondary">
                  0 content pieces
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sales Pipeline */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Target className="mr-2 h-5 w-5 text-green-600" />
            Sales Pipeline
          </CardTitle>
          <CardDescription>
            Track leads through your sales process
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Pipeline Stages */}
          <div className="grid grid-cols-5 gap-4 mb-8">
            {pipelineStages.map((stage, index) => (
              <div
                key={stage.name}
                className="text-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() =>
                  alert(
                    `📊 ${stage.name} Stage\n\nCurrent leads: ${stage.count}\n\nStage activities:\n• Lead qualification and scoring\n• Product presentations and samples\n• Pricing discussions and negotiations\n• Contract terms and compliance\n• Order confirmation and processing\n\nAverage time: ${index === 0 ? "7 days" : index === 1 ? "14 days" : index === 2 ? "21 days" : index === 3 ? "10 days" : "3 days"}`,
                  )
                }
              >
                <div
                  className={`w-8 h-8 ${stage.color} rounded-full mx-auto mb-2 flex items-center justify-center text-white text-sm font-bold`}
                >
                  {stage.count}
                </div>
                <h4 className="font-medium text-gray-900">{stage.name}</h4>
                <p className="text-xs text-gray-500">{stage.count} leads</p>
              </div>
            ))}
          </div>

          {/* Empty State for Pipeline */}
          <div className="text-center py-12">
            <Target className="mx-auto h-16 w-16 text-gray-400 mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">
              Build Your Sales Pipeline
            </h3>
            <p className="text-gray-500 mb-6 max-w-md mx-auto">
              Start generating leads using multiple channels and track them
              through your sales process for better conversion rates.
            </p>
            <div className="flex justify-center space-x-4">
              <Button onClick={handleAddLead}>
                <Plus className="mr-2 h-4 w-4" />
                Add First Lead
              </Button>
              <Button
                variant="outline"
                onClick={() =>
                  alert(
                    "🎯 Lead Scoring System\n\nQualify leads effectively:\n\n• Company size and buying power\n• Geographic market fit\n• Product interest alignment\n• Budget qualification\n• Decision timeline\n• Compliance readiness\n• Past import experience\n• Response engagement\n\nScore: 0-100 points for prioritization",
                  )
                }
              >
                <Target className="mr-2 h-4 w-4" />
                Lead Scoring
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderOrdersView = () => (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <ShoppingCart className="mr-2 h-5 w-5 text-purple-600" />
              Sales Orders
            </CardTitle>
            <CardDescription>
              Customer orders and sales transactions
            </CardDescription>
          </div>
          <Button
            onClick={() =>
              alert(
                "📝 Create Sales Order\n\nNew order workflow:\n\n• Customer selection\n• Product configuration\n• Pricing and terms\n• Delivery schedule\n• Payment terms\n• Export documentation\n• Quality requirements\n• Compliance checks\n\nAutomatic export creation",
              )
            }
          >
            <Plus className="mr-2 h-4 w-4" />
            New Order
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Empty State for Orders */}
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingCart className="h-12 w-12 text-purple-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No Sales Orders Yet
          </h3>
          <p className="text-gray-600 mb-8 max-w-md mx-auto">
            Convert your leads into sales orders. Track order status, manage
            fulfillment, and automatically generate export shipments.
          </p>

          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
              <div
                className="bg-blue-50 p-4 rounded-lg text-center cursor-pointer hover:bg-blue-100 transition-colors"
                onClick={() =>
                  alert(
                    "📋 Order Management\n\nFeatures:\n\n• Order tracking\n• Status updates\n• Customer notifications\n• Payment tracking\n• Delivery coordination\n• Document generation\n• Quality checkpoints\n• Customer feedback",
                  )
                }
              >
                <FileText className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <h4 className="font-semibold text-blue-900 mb-1">
                  Order Tracking
                </h4>
                <p className="text-sm text-blue-700">
                  Complete order lifecycle management
                </p>
              </div>

              <div
                className="bg-green-50 p-4 rounded-lg text-center cursor-pointer hover:bg-green-100 transition-colors"
                onClick={() =>
                  alert(
                    "🔄 Automated Workflow\n\nOrder to export flow:\n\n• Order confirmation\n• Inventory allocation\n• Production planning\n• Quality testing\n• Export documentation\n• Shipping arrangement\n• Customer updates\n• Payment processing",
                  )
                }
              >
                <RefreshCw className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <h4 className="font-semibold text-green-900 mb-1">
                  Automated Flow
                </h4>
                <p className="text-sm text-green-700">
                  Seamless order-to-export process
                </p>
              </div>

              <div
                className="bg-purple-50 p-4 rounded-lg text-center cursor-pointer hover:bg-purple-100 transition-colors"
                onClick={() =>
                  alert(
                    "💰 Revenue Tracking\n\nSales analytics:\n\n• Order values\n• Profit margins\n• Customer lifetime value\n• Product performance\n• Market analysis\n• Seasonal trends\n• Forecasting\n• Commission tracking",
                  )
                }
              >
                <DollarSign className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <h4 className="font-semibold text-purple-900 mb-1">
                  Revenue Analytics
                </h4>
                <p className="text-sm text-purple-700">
                  Sales performance insights
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Users className="mr-3 h-8 w-8 text-blue-600" />
              CRM & Sales
            </h1>
            <p className="text-gray-600 mt-1">
              Customer relationship management and sales pipeline for{" "}
              {COMPANY_INFO.name}
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Database className="w-4 h-4 mr-2" />
              Ready for Customer Data
            </Badge>
            <Button variant="outline" onClick={handleSetupCRM}>
              <Settings className="mr-2 h-4 w-4" />
              Setup CRM
            </Button>
            <Button
              className="bg-blue-600 text-white hover:bg-blue-700"
              onClick={handleAddCustomer}
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Add Customer
            </Button>
          </div>
        </motion.div>

        {/* CRM Overview Stats */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Customers
                </CardTitle>
                <Building className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <UserPlus className="h-4 w-4 mr-1" />
                  Add customers
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Active Leads
                </CardTitle>
                <Target className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Plus className="h-4 w-4 mr-1" />
                  Create leads
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Sales Orders
                </CardTitle>
                <ShoppingCart className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Activity className="h-4 w-4 mr-1" />
                  Track orders
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Revenue (YTD)
                </CardTitle>
                <DollarSign className="h-4 w-4 text-gold-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">₹0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  Start selling
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* View Selector */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 items-center justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700">View:</span>
            {[
              { id: "customers", label: "Customers", icon: Building },
              { id: "leads", label: "Sales Pipeline", icon: Target },
              { id: "orders", label: "Orders", icon: ShoppingCart },
            ].map((view) => {
              const Icon = view.icon;
              return (
                <Button
                  key={view.id}
                  variant={selectedView === view.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedView(view.id)}
                  className="flex items-center"
                >
                  <Icon className="mr-2 h-4 w-4" />
                  {view.label}
                </Button>
              );
            })}
          </div>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search customers, leads, orders..."
                className="pl-10 w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                alert(
                  "🔍 Advanced Search\n\nSearch and filter options:\n\n• Customer name and company\n• Market region\n• Product interests\n• Order history\n• Lead status\n• Revenue range\n• Last contact date\n• Custom fields\n\nSave frequently used searches",
                )
              }
            >
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </div>
        </motion.div>

        {/* Main Content Area */}
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <motion.div
            className="lg:col-span-3"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            {selectedView === "customers" && renderCustomersView()}
            {selectedView === "leads" && renderLeadsView()}
            {selectedView === "orders" && renderOrdersView()}
          </motion.div>

          {/* Sidebar */}
          <motion.div
            className="space-y-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            {/* Lead Generation Tools */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="mr-2 h-5 w-5 text-yellow-600" />
                    Lead Generation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🌐 Digital Marketing Tools\n\nOnline lead generation:\n\n• Google Ads setup for spice keywords\n• LinkedIn Sales Navigator searches\n• Industry directory scraping\n• SEO content optimization\n• Social media campaigns\n• B2B marketplace presence\n• Website lead capture forms\n• Landing page optimization\n\nTarget: Spice importers globally",
                      )
                    }
                  >
                    <Globe className="mr-2 h-4 w-4" />
                    Digital Marketing
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📞 Cold Outreach Tools\n\nDirect prospecting:\n\n• Import/export databases\n• Email finder and verifier\n• LinkedIn connection requests\n• Cold email templates\n• Phone scripts for calls\n• Follow-up sequences\n• Response tracking\n• A/B test messaging\n\nPersonalized for each market",
                      )
                    }
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    Cold Outreach
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🤝 Referral Program\n\nNetwork-based leads:\n\n• Customer referral incentives\n• Partner channel setup\n• Industry networking events\n• Trade association memberships\n• Government trade missions\n• Supplier introductions\n• Commission structures\n• Tracking and rewards\n\nLeverage existing relationships",
                      )
                    }
                  >
                    <Heart className="mr-2 h-4 w-4" />
                    Referral Program
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Engagement Tools */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="mr-2 h-5 w-5 text-green-600" />
                    Engagement Tools
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📦 Sample Management\n\nProduct sampling program:\n\n• Sample kit creation (9 spices)\n• Shipping and logistics\n• Custom packaging design\n• Quality certificates included\n• Recipe cards and usage guides\n• Follow-up questionnaires\n• Feedback collection\n• Conversion tracking\n\nCost: ₹500 per kit, ROI: 300%",
                      )
                    }
                  >
                    <Package className="mr-2 h-4 w-4" />
                    Sample Program
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📧 Email Automation\n\nNurturing campaigns:\n\n• Welcome series (7 emails)\n• Educational content delivery\n• Product catalogs and pricing\n• Market insights sharing\n• Success stories and testimonials\n• Seasonal promotions\n• Re-engagement campaigns\n• Win-back sequences\n\nPersonalized by market and interests",
                      )
                    }
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    Email Sequences
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🎥 Content Marketing\n\nEducational content strategy:\n\n• Spice farming and processing videos\n• Quality testing demonstrations\n• Cooking tutorials and recipes\n• Health benefits presentations\n• Market trend webinars\n• Customer success stories\n• Certification explanations\n• Virtual facility tours\n\nBuild trust and expertise",
                      )
                    }
                  >
                    <Video className="mr-2 h-4 w-4" />
                    Content Strategy
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Actions */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📊 Lead Analytics\n\nLead generation reports:\n\n• Source performance analysis\n• Conversion rates by channel\n• Cost per lead breakdown\n• Lead quality scoring\n• Pipeline velocity metrics\n• Engagement tracking\n• ROI calculations\n• Campaign effectiveness\n\nOptimize your lead generation",
                      )
                    }
                  >
                    <BarChart3 className="mr-2 h-4 w-4" />
                    Lead Analytics
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={handleImportCustomers}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Import Leads
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🎯 Lead Scoring\n\nQualification system:\n\n• Company size and revenue\n• Geographic market alignment\n• Product interest matching\n• Budget qualification\n• Decision timeline\n• Import experience\n• Compliance readiness\n• Engagement level\n\nScore: 0-100 points for prioritization",
                      )
                    }
                  >
                    <Target className="mr-2 h-4 w-4" />
                    Lead Scoring
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Market Overview */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="mr-2 h-5 w-5 text-purple-600" />
                    Market Overview
                  </CardTitle>
                  <CardDescription>
                    Customer distribution by market
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {TARGET_MARKETS.map((market) => (
                      <div
                        key={market.id}
                        className="flex items-center justify-between p-2 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                        onClick={() =>
                          alert(
                            `${market.flag} ${market.name} Market\n\nCustomers: 0\nRevenue: ₹0\nKey Products: ${market.keyProducts.join(", ")}\nSpecial Requirements: ${market.specialRequirements.join(", ")}\n\nMarket Opportunities:\n• Growing spice demand\n• Quality premium pricing\n• Long-term partnerships`,
                          )
                        }
                      >
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">{market.flag}</span>
                          <div>
                            <span className="text-sm font-medium text-gray-900">
                              {market.name}
                            </span>
                            <p className="text-xs text-gray-500">0 customers</p>
                          </div>
                        </div>
                        <Badge variant="outline">{market.exportVolume}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Getting Started */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="mr-2 h-5 w-5 text-gold-600" />
                    Getting Started
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-semibold text-blue-600">
                        1
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Import Customers
                        </p>
                        <p className="text-xs text-gray-500">
                          Add existing customer database
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        2
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Setup Pipeline
                        </p>
                        <p className="text-xs text-gray-500">
                          Configure sales stages and processes
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        3
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Generate Leads
                        </p>
                        <p className="text-xs text-gray-500">
                          Start adding prospects and opportunities
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button className="w-full mt-4" onClick={handleSetupCRM}>
                    <Settings className="mr-2 h-4 w-4" />
                    Start CRM Setup
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
