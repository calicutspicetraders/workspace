import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Globe,
  Shield,
  TrendingUp,
  Users,
  MapPin,
  Phone,
  Mail,
  ExternalLink,
  Award,
  Truck,
  BarChart3,
  FileCheck,
  Building,
  Search,
  Ship,
  FileText,
  MessageSquare,
  LayoutDashboard,
  LogIn,
  Crown,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import {
  COMPANY_INFO,
  PRODUCTS,
  TARGET_MARKETS,
  CERTIFICATIONS,
} from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const currentYear = new Date().getFullYear();

export default function Index() {
  console.log("🏠 Homepage component loaded");

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="spice-gradient min-h-screen flex items-center justify-center text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <motion.div
          className="relative z-10 text-center px-6 max-w-6xl mx-auto"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div
            className="inline-flex items-center px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm font-medium mb-8 border border-white/20"
            variants={fadeInUp}
          >
            <div className="w-2 h-2 bg-gold-400 rounded-full mr-2 animate-pulse"></div>
            Digital Workspace Portal
          </motion.div>

          <motion.h1
            className="text-4xl lg:text-6xl font-bold mb-6"
            variants={fadeInUp}
          >
            {COMPANY_INFO.name}
          </motion.h1>

          <motion.p
            className="text-xl lg:text-2xl font-light mb-8 max-w-3xl mx-auto text-spice-100"
            variants={fadeInUp}
          >
            {COMPANY_INFO.tagline}
          </motion.p>

          <motion.p
            className="text-lg mb-12 max-w-2xl mx-auto text-spice-200"
            variants={fadeInUp}
          >
            {COMPANY_INFO.description}
          </motion.p>

          {/* Global Search Demo */}
          <motion.div className="max-w-2xl mx-auto mb-12" variants={fadeInUp}>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search across all sections: customers, exports, documents, team..."
                className="pl-12 pr-24 py-4 text-lg border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white placeholder-white/70 rounded-xl focus:border-gold-400 focus:bg-white/20"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    const searchTerm = (e.target as HTMLInputElement).value;
                    if (searchTerm.trim()) {
                      alert(
                        `🔍 Global Search Demo: "${searchTerm}"\n\nThis search would find results across ALL sections:\n\n🏢 CRM & SALES\n• Customer companies and contacts\n• Lead information and opportunities\n• Sales orders and revenue data\n\n📦 EXPORT SHIPMENTS\n• Export numbers and tracking\n• Customer shipments and status\n• Product quantities and destinations\n\n📄 DOCUMENTS\n• Certificates and licenses\n• Export documentation\n• Quality reports and compliance\n\n👥 TEAM MEMBERS\n• Employee names and roles\n• Departments and expertise\n• Contact information\n\n🛡️ COMPLIANCE\n• Certificate names and numbers\n• Authority information\n• Expiry dates and renewals\n\n📊 ANALYTICS\n• Reports and metrics\n• Market performance data\n• Revenue insights\n\n💬 COMMUNICATION\n• Messages and conversations\n• Email campaigns\n• Team communications\n\nExample searches:\n• "cardamom" - finds products, customers, exports\n• "UAE customers" - finds regional customers\n• "FSSAI certificate" - finds compliance documents\n• "export manager" - finds team members\n• "status:active" - filters by status\n• "market:Dubai" - filters by location\n\nReal-time results with instant filtering and section navigation!`,
                      );
                    }
                  }
                }}
              />
              <Button
                size="sm"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gold-500 hover:bg-gold-600 text-gray-900 font-semibold"
                onClick={() =>
                  alert(
                    "🚀 Advanced Search Features\n\nComprehensive search across:\n\n✅ All 8 workspace sections\n✅ Advanced filters and operators\n✅ Real-time suggestions\n✅ Smart categorization\n✅ Quick navigation to results\n✅ Export search results\n✅ Save search queries\n✅ Team search sharing\n\nTry searching for: customers, exports, certificates, team members, etc.",
                  )
                }
              >
                Search
              </Button>
            </div>
            <p className="text-sm text-white/70 mt-2">
              Try: "cardamom exports", "UAE customers", "certificates", "team
              members"
            </p>
          </motion.div>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            variants={fadeInUp}
          >
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="spice-gradient text-white shadow-lg hover:shadow-xl transition-all"
              >
                <Link to="/login">
                  <LogIn className="mr-2 h-5 w-5" />
                  Access Workspace
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10"
              >
                <Link to="/superadmin-login">
                  <Crown className="mr-2 h-4 w-4" />
                  SuperAdmin
                </Link>
              </Button>
            </div>

            <Button
              variant="outline"
              size="lg"
              className="border-white/30 text-white hover:bg-white/10 px-8 py-3 text-lg"
              onClick={() =>
                alert(
                  "🌐 Company Website\n\nThis would redirect to:\nhttps://calicutspicetraders.com\n\nThe main company website with:\n• Product catalog\n• Company history\n• Contact information\n• Customer testimonials\n• Global certifications",
                )
              }
            >
              <Globe className="mr-2 h-5 w-5" />
              Visit Website
            </Button>
          </motion.div>
        </motion.div>
      </section>

      {/* Quick Access Modules */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive Digital Workspace
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Access all your business modules from one integrated platform.
              Search across everything, manage workflows, and grow your spice
              export business.
            </p>
          </motion.div>

          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-blue-100 rounded-xl flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                    <Building className="h-8 w-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    CRM & Sales
                  </CardTitle>
                  <CardDescription>
                    Customer management and sales pipeline
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button asChild className="w-full spice-gradient text-white">
                    <Link to="/crm">
                      Access CRM
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-green-100 rounded-xl flex items-center justify-center group-hover:bg-green-200 transition-colors">
                    <Ship className="h-8 w-8 text-green-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    Export Management
                  </CardTitle>
                  <CardDescription>
                    Track shipments and logistics
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button asChild className="w-full spice-gradient text-white">
                    <Link to="/exports">
                      Manage Exports
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-purple-100 rounded-xl flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                    <FileText className="h-8 w-8 text-purple-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    Document Center
                  </CardTitle>
                  <CardDescription>Secure document management</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button asChild className="w-full spice-gradient text-white">
                    <Link to="/documents">
                      View Documents
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-orange-100 rounded-xl flex items-center justify-center group-hover:bg-orange-200 transition-colors">
                    <BarChart3 className="h-8 w-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    Analytics Hub
                  </CardTitle>
                  <CardDescription>
                    Business intelligence and insights
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button asChild className="w-full spice-gradient text-white">
                    <Link to="/analytics">
                      View Analytics
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>

          {/* Additional Modules Row */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-red-100 rounded-xl flex items-center justify-center group-hover:bg-red-200 transition-colors">
                    <Shield className="h-8 w-8 text-red-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    Compliance Center
                  </CardTitle>
                  <CardDescription>
                    Certificate and regulatory management
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button asChild className="w-full spice-gradient text-white">
                    <Link to="/compliance">
                      Check Compliance
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-indigo-100 rounded-xl flex items-center justify-center group-hover:bg-indigo-200 transition-colors">
                    <Users className="h-8 w-8 text-indigo-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    Team Hub
                  </CardTitle>
                  <CardDescription>
                    Team management and collaboration
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button asChild className="w-full spice-gradient text-white">
                    <Link to="/team">
                      Manage Team
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-pink-100 rounded-xl flex items-center justify-center group-hover:bg-pink-200 transition-colors">
                    <MessageSquare className="h-8 w-8 text-pink-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    Communication
                  </CardTitle>
                  <CardDescription>
                    Integrated team communication
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button asChild className="w-full spice-gradient text-white">
                    <Link to="/communication">
                      Open Comms
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow card-hover group">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 mx-auto bg-gray-100 rounded-xl flex items-center justify-center group-hover:bg-gray-200 transition-colors">
                    <Search className="h-8 w-8 text-gray-600" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900">
                    Global Search
                  </CardTitle>
                  <CardDescription>Search across all sections</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button
                    className="w-full spice-gradient text-white"
                    onClick={() =>
                      alert(
                        "🔍 Global Search\n\nSearch across all 8 sections:\n\n• CRM & Sales\n• Export Shipments\n• Documents\n• Team Members\n• Compliance\n• Analytics\n• Communication\n• Company Data\n\nUse the search bar in the header of any page!",
                      )
                    }
                  >
                    Try Search
                    <Search className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-16 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Company Overview
            </h2>
            <p className="text-lg text-gray-600">
              Your trusted partner for premium Kerala spices to global markets
            </p>
          </motion.div>

          <motion.div
            className="grid lg:grid-cols-2 gap-12 items-center"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-gradient-to-br from-spice-500 to-spice-600 text-white border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-white">
                    Quick Stats
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-spice-100">Established</span>
                    <span className="font-semibold text-gold-300">
                      {COMPANY_INFO.establishedYear}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-spice-100">Business Partners</span>
                    <span className="font-semibold text-gold-300">
                      {COMPANY_INFO.partners}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-spice-100">Certifications</span>
                    <span className="font-semibold text-gold-300">
                      {CERTIFICATIONS.length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-spice-100">Export Products</span>
                    <span className="font-semibold text-gold-300">
                      {PRODUCTS.length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-spice-100">Target Markets</span>
                    <span className="font-semibold text-gold-300">
                      {TARGET_MARKETS.length}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div className="space-y-6" variants={fadeInUp}>
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Contact Information
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 text-spice-600 mr-3" />
                    <span className="text-gray-700">
                      {COMPANY_INFO.contact.address}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-spice-600 mr-3" />
                    <span className="text-gray-700">
                      {COMPANY_INFO.contact.phone}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-spice-600 mr-3" />
                    <span className="text-gray-700">
                      {COMPANY_INFO.contact.email}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Search Capabilities
                </h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center">
                    <Search className="h-4 w-4 text-spice-600 mr-2" />
                    <span>Customer Data</span>
                  </div>
                  <div className="flex items-center">
                    <Search className="h-4 w-4 text-spice-600 mr-2" />
                    <span>Export Records</span>
                  </div>
                  <div className="flex items-center">
                    <Search className="h-4 w-4 text-spice-600 mr-2" />
                    <span>Documents</span>
                  </div>
                  <div className="flex items-center">
                    <Search className="h-4 w-4 text-spice-600 mr-2" />
                    <span>Team Directory</span>
                  </div>
                  <div className="flex items-center">
                    <Search className="h-4 w-4 text-spice-600 mr-2" />
                    <span>Compliance</span>
                  </div>
                  <div className="flex items-center">
                    <Search className="h-4 w-4 text-spice-600 mr-2" />
                    <span>Analytics</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="w-8 h-8 spice-gradient rounded-lg flex items-center justify-center mr-3">
              <span className="text-white font-bold text-sm">
                {COMPANY_INFO.shortName}
              </span>
            </div>
            <span className="font-semibold text-white">
              {COMPANY_INFO.name}
            </span>
          </div>
          <p className="text-sm text-gray-400 mb-4">{COMPANY_INFO.tagline}</p>
          <p className="text-xs text-gray-500">
            © {currentYear} {COMPANY_INFO.name}. All rights reserved. |
            Established {COMPANY_INFO.establishedYear}
          </p>
        </div>
      </footer>
    </div>
  );
}
