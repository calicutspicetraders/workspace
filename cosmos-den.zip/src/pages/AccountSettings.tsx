import React, { useState } from "react";
import { Layout } from "../components/Layout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Badge } from "../components/ui/badge";
import { Separator } from "../components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import {
  User,
  Settings,
  Bell,
  Shield,
  Key,
  Globe,
  Camera,
  Save,
  Mail,
  Phone,
  MapPin,
  Building2,
  Clock,
  CheckCircle,
} from "lucide-react";
import { useToast } from "../hooks/use-toast";

interface UserProfile {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  jobTitle: string;
  department: string;
  location: string;
  bio: string;
  avatar: string;
}

interface NotificationSettings {
  emailNotifications: boolean;
  pushNotifications: boolean;
  smsAlerts: boolean;
  marketingEmails: boolean;
  exportAlerts: boolean;
  complianceReminders: boolean;
  teamUpdates: boolean;
  systemMaintenance: boolean;
}

interface SecuritySettings {
  twoFactorEnabled: boolean;
  sessionTimeout: string;
  passwordLastChanged: string;
  loginNotifications: boolean;
}

interface PreferenceSettings {
  language: string;
  timezone: string;
  dateFormat: string;
  currency: string;
  theme: string;
  dashboardLayout: string;
}

export default function AccountSettings() {
  const { toast } = useToast();

  const [userProfile, setUserProfile] = useState<UserProfile>({
    firstName: "Admin",
    lastName: "User",
    email: "admin@calicutspicetraders.com",
    phone: "+91 9876543210",
    jobTitle: "Export Manager",
    department: "International Trade",
    location: "Calicut, Kerala, India",
    bio: "Experienced export manager specializing in spice trade to international markets. Leading digital transformation initiatives for efficient export operations.",
    avatar: "",
  });

  const [notifications, setNotifications] = useState<NotificationSettings>({
    emailNotifications: true,
    pushNotifications: true,
    smsAlerts: true,
    marketingEmails: false,
    exportAlerts: true,
    complianceReminders: true,
    teamUpdates: true,
    systemMaintenance: true,
  });

  const [security, setSecurity] = useState<SecuritySettings>({
    twoFactorEnabled: false,
    sessionTimeout: "8h",
    passwordLastChanged: "2024-01-15",
    loginNotifications: true,
  });

  const [preferences, setPreferences] = useState<PreferenceSettings>({
    language: "en",
    timezone: "Asia/Kolkata",
    dateFormat: "DD/MM/YYYY",
    currency: "INR",
    theme: "light",
    dashboardLayout: "compact",
  });

  const [activeTab, setActiveTab] = useState("profile");

  const handleSaveProfile = () => {
    toast({
      title: "Profile Updated",
      description: "Your profile information has been saved successfully.",
    });
  };

  const handleSaveNotifications = () => {
    toast({
      title: "Notification Settings Updated",
      description: "Your notification preferences have been saved.",
    });
  };

  const handleSaveSecurity = () => {
    toast({
      title: "Security Settings Updated",
      description: "Your security settings have been updated successfully.",
    });
  };

  const handleSavePreferences = () => {
    toast({
      title: "Preferences Updated",
      description: "Your system preferences have been saved.",
    });
  };

  return (
    <Layout>
      <div className="p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
              <Settings className="h-8 w-8 text-spice-600" />
              <h1 className="text-3xl font-bold text-gray-900">
                Account Settings
              </h1>
            </div>
            <p className="text-gray-600">
              Manage your account profile, preferences, and security settings
            </p>
          </div>

          {/* Settings Tabs */}
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="space-y-6"
          >
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger
                value="profile"
                className="flex items-center space-x-2"
              >
                <User className="h-4 w-4" />
                <span>Profile</span>
              </TabsTrigger>
              <TabsTrigger
                value="notifications"
                className="flex items-center space-x-2"
              >
                <Bell className="h-4 w-4" />
                <span>Notifications</span>
              </TabsTrigger>
              <TabsTrigger
                value="security"
                className="flex items-center space-x-2"
              >
                <Shield className="h-4 w-4" />
                <span>Security</span>
              </TabsTrigger>
              <TabsTrigger
                value="preferences"
                className="flex items-center space-x-2"
              >
                <Globe className="h-4 w-4" />
                <span>Preferences</span>
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <User className="h-5 w-5" />
                    <span>Personal Information</span>
                  </CardTitle>
                  <CardDescription>
                    Update your personal details and contact information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Avatar Section */}
                  <div className="flex items-center space-x-6">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={userProfile.avatar} />
                      <AvatarFallback className="bg-spice-500 text-white text-lg">
                        {userProfile.firstName[0]}
                        {userProfile.lastName[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-2">
                      <Button variant="outline" size="sm">
                        <Camera className="h-4 w-4 mr-2" />
                        Change Photo
                      </Button>
                      <p className="text-sm text-gray-500">
                        JPG, GIF or PNG. 1MB max.
                      </p>
                    </div>
                  </div>

                  <Separator />

                  {/* Basic Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={userProfile.firstName}
                        onChange={(e) =>
                          setUserProfile({
                            ...userProfile,
                            firstName: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={userProfile.lastName}
                        onChange={(e) =>
                          setUserProfile({
                            ...userProfile,
                            lastName: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                          id="email"
                          type="email"
                          value={userProfile.email}
                          className="pl-10"
                          onChange={(e) =>
                            setUserProfile({
                              ...userProfile,
                              email: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                          id="phone"
                          value={userProfile.phone}
                          className="pl-10"
                          onChange={(e) =>
                            setUserProfile({
                              ...userProfile,
                              phone: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="jobTitle">Job Title</Label>
                      <div className="relative">
                        <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                          id="jobTitle"
                          value={userProfile.jobTitle}
                          className="pl-10"
                          onChange={(e) =>
                            setUserProfile({
                              ...userProfile,
                              jobTitle: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="department">Department</Label>
                      <Select
                        value={userProfile.department}
                        onValueChange={(value) =>
                          setUserProfile({ ...userProfile, department: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="International Trade">
                            International Trade
                          </SelectItem>
                          <SelectItem value="Export Operations">
                            Export Operations
                          </SelectItem>
                          <SelectItem value="Quality Control">
                            Quality Control
                          </SelectItem>
                          <SelectItem value="Compliance">Compliance</SelectItem>
                          <SelectItem value="Finance">Finance</SelectItem>
                          <SelectItem value="Logistics">Logistics</SelectItem>
                          <SelectItem value="Administration">
                            Administration
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="location"
                        value={userProfile.location}
                        className="pl-10"
                        onChange={(e) =>
                          setUserProfile({
                            ...userProfile,
                            location: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      value={userProfile.bio}
                      rows={4}
                      onChange={(e) =>
                        setUserProfile({ ...userProfile, bio: e.target.value })
                      }
                    />
                  </div>

                  <Button
                    onClick={handleSaveProfile}
                    className="spice-gradient text-white"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Profile
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Bell className="h-5 w-5" />
                    <span>Notification Preferences</span>
                  </CardTitle>
                  <CardDescription>
                    Choose how you want to receive notifications and alerts
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* General Notifications */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">
                      General Notifications
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Email Notifications</Label>
                          <p className="text-sm text-gray-500">
                            Receive notifications via email
                          </p>
                        </div>
                        <Switch
                          checked={notifications.emailNotifications}
                          onCheckedChange={(checked) =>
                            setNotifications({
                              ...notifications,
                              emailNotifications: checked,
                            })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Push Notifications</Label>
                          <p className="text-sm text-gray-500">
                            Receive browser push notifications
                          </p>
                        </div>
                        <Switch
                          checked={notifications.pushNotifications}
                          onCheckedChange={(checked) =>
                            setNotifications({
                              ...notifications,
                              pushNotifications: checked,
                            })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>SMS Alerts</Label>
                          <p className="text-sm text-gray-500">
                            Receive urgent alerts via SMS
                          </p>
                        </div>
                        <Switch
                          checked={notifications.smsAlerts}
                          onCheckedChange={(checked) =>
                            setNotifications({
                              ...notifications,
                              smsAlerts: checked,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Export & Business Notifications */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">
                      Business Notifications
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Export Alerts</Label>
                          <p className="text-sm text-gray-500">
                            Shipment updates, documentation, and status changes
                          </p>
                        </div>
                        <Switch
                          checked={notifications.exportAlerts}
                          onCheckedChange={(checked) =>
                            setNotifications({
                              ...notifications,
                              exportAlerts: checked,
                            })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Compliance Reminders</Label>
                          <p className="text-sm text-gray-500">
                            Certificate renewals and regulatory updates
                          </p>
                        </div>
                        <Switch
                          checked={notifications.complianceReminders}
                          onCheckedChange={(checked) =>
                            setNotifications({
                              ...notifications,
                              complianceReminders: checked,
                            })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Team Updates</Label>
                          <p className="text-sm text-gray-500">
                            Team activities and collaboration updates
                          </p>
                        </div>
                        <Switch
                          checked={notifications.teamUpdates}
                          onCheckedChange={(checked) =>
                            setNotifications({
                              ...notifications,
                              teamUpdates: checked,
                            })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>System Maintenance</Label>
                          <p className="text-sm text-gray-500">
                            Scheduled maintenance and system updates
                          </p>
                        </div>
                        <Switch
                          checked={notifications.systemMaintenance}
                          onCheckedChange={(checked) =>
                            setNotifications({
                              ...notifications,
                              systemMaintenance: checked,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={handleSaveNotifications}
                    className="spice-gradient text-white"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Notifications
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="h-5 w-5" />
                    <span>Security Settings</span>
                  </CardTitle>
                  <CardDescription>
                    Manage your account security and access controls
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Two-Factor Authentication */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">
                      Two-Factor Authentication
                    </h3>
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="space-y-0.5">
                          <Label>Enable 2FA</Label>
                          <p className="text-sm text-gray-500">
                            Add an extra layer of security to your account
                          </p>
                        </div>
                        <Switch
                          checked={security.twoFactorEnabled}
                          onCheckedChange={(checked) =>
                            setSecurity({
                              ...security,
                              twoFactorEnabled: checked,
                            })
                          }
                        />
                      </div>
                      {security.twoFactorEnabled && (
                        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                          <div className="flex items-center text-green-800">
                            <CheckCircle className="h-4 w-4 mr-2" />
                            <span className="text-sm font-medium">
                              2FA is enabled
                            </span>
                          </div>
                          <p className="text-sm text-green-700 mt-1">
                            Your account is protected with two-factor
                            authentication
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  {/* Password */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Password</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="space-y-0.5">
                          <Label>Password</Label>
                          <p className="text-sm text-gray-500">
                            Last changed: {security.passwordLastChanged}
                          </p>
                        </div>
                        <Button variant="outline">
                          <Key className="h-4 w-4 mr-2" />
                          Change Password
                        </Button>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Session Settings */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">
                      Session Management
                    </h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Session Timeout</Label>
                        <Select
                          value={security.sessionTimeout}
                          onValueChange={(value) =>
                            setSecurity({ ...security, sessionTimeout: value })
                          }
                        >
                          <SelectTrigger className="w-48">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1h">1 hour</SelectItem>
                            <SelectItem value="4h">4 hours</SelectItem>
                            <SelectItem value="8h">8 hours</SelectItem>
                            <SelectItem value="24h">24 hours</SelectItem>
                            <SelectItem value="never">Never expire</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Login Notifications</Label>
                          <p className="text-sm text-gray-500">
                            Get notified of new login attempts
                          </p>
                        </div>
                        <Switch
                          checked={security.loginNotifications}
                          onCheckedChange={(checked) =>
                            setSecurity({
                              ...security,
                              loginNotifications: checked,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={handleSaveSecurity}
                    className="spice-gradient text-white"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Security Settings
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Preferences Tab */}
            <TabsContent value="preferences" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Globe className="h-5 w-5" />
                    <span>System Preferences</span>
                  </CardTitle>
                  <CardDescription>
                    Customize your workspace appearance and behavior
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Localization */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Localization</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label>Language</Label>
                        <Select
                          value={preferences.language}
                          onValueChange={(value) =>
                            setPreferences({ ...preferences, language: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en">English</SelectItem>
                            <SelectItem value="hi">हिंदी (Hindi)</SelectItem>
                            <SelectItem value="ml">
                              മലയാളം (Malayalam)
                            </SelectItem>
                            <SelectItem value="ar">العربية (Arabic)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Timezone</Label>
                        <Select
                          value={preferences.timezone}
                          onValueChange={(value) =>
                            setPreferences({ ...preferences, timezone: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Asia/Kolkata">
                              Asia/Kolkata (IST)
                            </SelectItem>
                            <SelectItem value="Asia/Dubai">
                              Asia/Dubai (GST)
                            </SelectItem>
                            <SelectItem value="Europe/London">
                              Europe/London (GMT)
                            </SelectItem>
                            <SelectItem value="America/New_York">
                              America/New_York (EST)
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Date Format</Label>
                        <Select
                          value={preferences.dateFormat}
                          onValueChange={(value) =>
                            setPreferences({
                              ...preferences,
                              dateFormat: value,
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="DD/MM/YYYY">
                              DD/MM/YYYY
                            </SelectItem>
                            <SelectItem value="MM/DD/YYYY">
                              MM/DD/YYYY
                            </SelectItem>
                            <SelectItem value="YYYY-MM-DD">
                              YYYY-MM-DD
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Currency</Label>
                        <Select
                          value={preferences.currency}
                          onValueChange={(value) =>
                            setPreferences({ ...preferences, currency: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="INR">
                              ₹ Indian Rupee (INR)
                            </SelectItem>
                            <SelectItem value="USD">
                              $ US Dollar (USD)
                            </SelectItem>
                            <SelectItem value="AED">
                              د.إ UAE Dirham (AED)
                            </SelectItem>
                            <SelectItem value="EUR">€ Euro (EUR)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Appearance */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Appearance</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label>Theme</Label>
                        <Select
                          value={preferences.theme}
                          onValueChange={(value) =>
                            setPreferences({ ...preferences, theme: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="light">Light</SelectItem>
                            <SelectItem value="dark">Dark</SelectItem>
                            <SelectItem value="system">System</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Dashboard Layout</Label>
                        <Select
                          value={preferences.dashboardLayout}
                          onValueChange={(value) =>
                            setPreferences({
                              ...preferences,
                              dashboardLayout: value,
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="compact">Compact</SelectItem>
                            <SelectItem value="comfortable">
                              Comfortable
                            </SelectItem>
                            <SelectItem value="spacious">Spacious</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={handleSavePreferences}
                    className="spice-gradient text-white"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Preferences
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
}
