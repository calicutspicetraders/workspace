import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Users,
  User,
  UserPlus,
  Search,
  Filter,
  MoreHorizontal,
  Mail,
  Phone,
  MessageSquare,
  Video,
  Award,
  TrendingUp,
  TrendingDown,
  Target,
  CheckCircle,
  Clock,
  AlertTriangle,
  Star,
  Calendar,
  FileText,
  BarChart3,
  Settings,
  MapPin,
  Shield,
  Briefcase,
  Edit,
  Eye,
  Plus,
  Download,
  Database,
  Activity,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Layout } from "../components/Layout";
import { COMPANY_INFO } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

export default function Team() {
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState("grid");

  const handleAddTeamMember = () => {
    alert(
      "👥 Add New Team Member\n\nCreate new team member profile:\n\n• Personal information\n• Role and department assignment\n• Access permissions\n• Training requirements\n• Performance goals\n• Contact details\n• Certification tracking\n\nIntegrates with HR system and onboarding workflow",
    );
  };

  const handleSetupTeam = () => {
    alert(
      "⚙️ Setup Team Management\n\nGet started with:\n\n• Department structure\n• Role definitions\n• Performance metrics\n• Training programs\n• Communication channels\n• Goal setting\n• Access permissions\n• Workflow assignments",
    );
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Users className="mr-3 h-8 w-8 text-blue-600" />
              Team Hub
            </h1>
            <p className="text-gray-600 mt-1">
              Team management, collaboration, and performance tracking for{" "}
              {COMPANY_INFO.name}
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Database className="w-4 h-4 mr-2" />
              Ready for Team Setup
            </Badge>
            <Button variant="outline" onClick={handleSetupTeam}>
              <Settings className="mr-2 h-4 w-4" />
              Setup
            </Button>
            <Button
              className="bg-blue-600 text-white hover:bg-blue-700"
              onClick={handleAddTeamMember}
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Add Member
            </Button>
          </div>
        </motion.div>

        {/* Team Overview Stats - Empty State */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Members
                </CardTitle>
                <Users className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <UserPlus className="h-4 w-4 mr-1" />
                  Add team members
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Team Performance
                </CardTitle>
                <BarChart3 className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">--</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Target className="h-4 w-4 mr-1" />
                  Track performance
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Active Tasks
                </CardTitle>
                <Target className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Clock className="h-4 w-4 mr-1" />
                  Assign tasks
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Training Progress
                </CardTitle>
                <Award className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0%</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Settings className="h-4 w-4 mr-1" />
                  Setup training
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Filters and Search */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 items-center justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700">
              Department:
            </span>
            <select
              value={filterDepartment}
              onChange={(e) => setFilterDepartment(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Departments</option>
              <option value="operations">Operations</option>
              <option value="quality">Quality Assurance</option>
              <option value="logistics">Logistics</option>
              <option value="sales">Sales & Marketing</option>
              <option value="compliance">Compliance</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search team members..."
                className="pl-10 w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
            >
              {viewMode === "grid" ? "List View" : "Grid View"}
            </Button>
          </div>
        </motion.div>

        {/* Main Content - Empty State */}
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Team Members - Empty */}
          <motion.div
            className="lg:col-span-3"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-blue-600" />
                  Team Members
                </CardTitle>
                <CardDescription>No team members added yet</CardDescription>
              </CardHeader>
              <CardContent>
                {/* Empty State */}
                <div className="text-center py-16">
                  <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Users className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    No Team Members Yet
                  </h3>
                  <p className="text-gray-600 mb-8 max-w-md mx-auto">
                    Build your export team by adding members with their roles,
                    responsibilities, and contact information. Track performance
                    and manage collaboration effectively.
                  </p>

                  <div className="space-y-4">
                    <Button
                      className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3"
                      onClick={handleAddTeamMember}
                    >
                      <UserPlus className="mr-2 h-5 w-5" />
                      Add Your First Team Member
                    </Button>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mt-8">
                      <div className="bg-blue-50 p-4 rounded-lg text-center">
                        <User className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-blue-900 mb-1">
                          Team Profiles
                        </h4>
                        <p className="text-sm text-blue-700">
                          Detailed profiles with roles, skills, and contact info
                        </p>
                      </div>

                      <div className="bg-green-50 p-4 rounded-lg text-center">
                        <BarChart3 className="h-8 w-8 text-green-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-green-900 mb-1">
                          Performance Tracking
                        </h4>
                        <p className="text-sm text-green-700">
                          Monitor individual and team performance metrics
                        </p>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg text-center">
                        <MessageSquare className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-purple-900 mb-1">
                          Team Communication
                        </h4>
                        <p className="text-sm text-purple-700">
                          Integrated messaging and collaboration tools
                        </p>
                      </div>
                    </div>

                    <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center justify-center">
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
                        <span className="text-sm text-yellow-800">
                          Ready to build your export team?
                          <button
                            className="ml-1 underline hover:no-underline"
                            onClick={handleSetupTeam}
                          >
                            Start team setup
                          </button>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            className="space-y-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            {/* Quick Actions */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📅 Schedule Team Meeting\n\nOrganize team meetings:\n\n• Department meetings\n• All-hands meetings\n• Training sessions\n• Performance reviews\n• Project kick-offs\n• Compliance briefings\n\nIntegrates with calendar and sends notifications",
                      )
                    }
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    Schedule Meeting
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🎯 Performance Review\n\nConduct performance evaluations:\n\n• Individual assessments\n• Goal setting and tracking\n• Skill development plans\n• 360-degree feedback\n• Career progression\n• Training recommendations\n\nSchedule regular review cycles",
                      )
                    }
                  >
                    <Star className="mr-2 h-4 w-4" />
                    Performance Review
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🎓 Training Management\n\nManage team training:\n\n• Compliance training schedules\n• Skill development programs\n• Certification tracking\n• Progress monitoring\n• Resource allocation\n• External training coordination\n\nIntegrates with learning management system",
                      )
                    }
                  >
                    <Award className="mr-2 h-4 w-4" />
                    Manage Training
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Getting Started */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="mr-2 h-5 w-5 text-green-600" />
                    Getting Started
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-semibold text-blue-600">
                        1
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Add Team Members
                        </p>
                        <p className="text-xs text-gray-500">
                          Create profiles with roles and responsibilities
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        2
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Setup Departments
                        </p>
                        <p className="text-xs text-gray-500">
                          Organize team into functional departments
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        3
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Define Goals
                        </p>
                        <p className="text-xs text-gray-500">
                          Set performance metrics and objectives
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button className="w-full mt-4" onClick={handleSetupTeam}>
                    <Settings className="mr-2 h-4 w-4" />
                    Start Team Setup
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Department Structure */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Briefcase className="mr-2 h-5 w-5 text-purple-600" />
                    Department Structure
                  </CardTitle>
                  <CardDescription>
                    Recommended departments for export business
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { name: "Operations", icon: "⚙️", count: 0 },
                      { name: "Quality Assurance", icon: "🔍", count: 0 },
                      { name: "Logistics", icon: "🚚", count: 0 },
                      { name: "Sales & Marketing", icon: "📈", count: 0 },
                      { name: "Compliance", icon: "🛡️", count: 0 },
                    ].map((dept, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                        onClick={() =>
                          alert(
                            `🏢 ${dept.name} Department\n\nSuggested roles:\n• Department Head\n• Specialists\n• Coordinators\n• Assistants\n\nKey responsibilities for export operations`,
                          )
                        }
                      >
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">{dept.icon}</span>
                          <div>
                            <span className="text-sm font-medium text-gray-900">
                              {dept.name}
                            </span>
                            <p className="text-xs text-gray-500">
                              {dept.count} members
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          Setup
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
