import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Alert, AlertDescription } from "../components/ui/alert";
import { Separator } from "../components/ui/separator";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  LogIn,
  Shield,
  Users,
  AlertCircle,
  Chrome,
  ArrowLeft,
  Home,
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { COMPANY_INFO } from "../lib/constants";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isGoogleLogin, setIsGoogleLogin] = useState(false);

  const { login, loginWithGoogle, isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as any)?.from?.pathname || "/dashboard";

  useEffect(() => {
    if (isAuthenticated) {
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, navigate, from]);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Please enter both email and password");
      return;
    }

    setIsLoggingIn(true);
    setError("");

    const result = await login(email, password);
    if (result.success) {
      navigate(from, { replace: true });
    } else {
      setError(result.error || "Login failed");
    }
    setIsLoggingIn(false);
  };

  const handleGoogleLogin = async () => {
    setIsGoogleLogin(true);
    setError("");

    const result = await loginWithGoogle();
    if (result.success) {
      navigate(from, { replace: true });
    } else {
      setError(result.error || "Google login failed");
    }
    setIsGoogleLogin(false);
  };

  const demoCredentials = [
    {
      email: "admin@calicutspicetraders.com",
      password: "admin123",
      role: "Admin",
    },
    {
      email: "manager@calicutspicetraders.com",
      password: "manager123",
      role: "Export Manager",
    },
    {
      email: "quality@calicutspicetraders.com",
      password: "quality123",
      role: "Quality Inspector",
    },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-spice-500 to-spice-600 flex items-center justify-center">
        <div className="animate-pulse text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-spice-500 to-spice-600 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Back Navigation */}
        <div className="flex items-center justify-between text-white">
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10 -ml-2"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
            onClick={() => navigate("/")}
          >
            <Home className="h-4 w-4" />
          </Button>
        </div>

        {/* Header */}
        <div className="text-center text-white">
          <div className="mx-auto w-16 h-16 spice-gradient rounded-2xl flex items-center justify-center mb-4 shadow-lg">
            <span className="text-white font-bold text-xl">
              {COMPANY_INFO.shortName}
            </span>
          </div>
          <h1 className="text-3xl font-bold">Welcome Back</h1>
          <p className="text-spice-100 mt-2">
            Sign in to access your workspace
          </p>
        </div>

        {/* Login Card */}
        <Card className="bg-white/95 backdrop-blur border-0 shadow-xl">
          <CardHeader className="text-center pb-4">
            <CardTitle className="flex items-center justify-center space-x-2">
              <Shield className="h-5 w-5 text-spice-600" />
              <span>Secure Access</span>
            </CardTitle>
            <CardDescription>
              Only authorized team members can access the workspace
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Error Alert */}
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Google Login */}
            <Button
              type="button"
              variant="outline"
              className="w-full h-12"
              onClick={handleGoogleLogin}
              disabled={isGoogleLogin || isLoggingIn}
            >
              {isGoogleLogin ? (
                <div className="animate-spin h-4 w-4 border-2 border-gray-300 border-t-gray-600 rounded-full" />
              ) : (
                <Chrome className="h-5 w-5 mr-2" />
              )}
              {isGoogleLogin ? "Signing in..." : "Continue with Google"}
            </Button>

            <div className="relative">
              <Separator />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="bg-white px-2 text-sm text-gray-500">or</span>
              </div>
            </div>

            {/* Email/Password Form */}
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    placeholder="your.email@calicutspicetraders.com"
                    disabled={isLoggingIn || isGoogleLogin}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                    placeholder="Enter your password"
                    disabled={isLoggingIn || isGoogleLogin}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoggingIn || isGoogleLogin}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-12 spice-gradient text-white"
                disabled={isLoggingIn || isGoogleLogin || !email || !password}
              >
                {isLoggingIn ? (
                  <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                ) : (
                  <LogIn className="h-4 w-4 mr-2" />
                )}
                {isLoggingIn ? "Signing in..." : "Sign In"}
              </Button>
            </form>

            <Separator />

            {/* Demo Credentials */}
            <div className="space-y-3">
              <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                <Users className="h-4 w-4" />
                <span>Demo Credentials</span>
              </div>
              <div className="space-y-2">
                {demoCredentials.map((cred, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="w-full text-left justify-start h-auto p-3"
                    onClick={() => {
                      setEmail(cred.email);
                      setPassword(cred.password);
                    }}
                    disabled={isLoggingIn || isGoogleLogin}
                  >
                    <div className="text-left">
                      <div className="font-medium text-sm">{cred.role}</div>
                      <div className="text-xs text-gray-500">{cred.email}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Notice */}
        <Card className="bg-white/10 backdrop-blur border-white/20 text-white">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Shield className="h-5 w-5 text-gold-300 mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-medium mb-1">Secure Access</p>
                <p className="text-spice-100 text-xs">
                  Only team members with valid credentials can access the
                  workspace. New users must be invited by an administrator and
                  approved before gaining access.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Support */}
        <div className="text-center">
          <p className="text-spice-100 text-sm mb-2">
            Need access or having trouble?
          </p>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
            onClick={() =>
              alert(
                "📞 Contact Support\n\nFor access requests or login issues:\n\n📧 Email: admin@calicutspicetraders.com\n📱 Phone: +91 495 123 4567\n💬 WhatsApp: +91 9876543210\n\n🔐 Security Notice:\nOnly administrators can grant workspace access to new team members.",
              )
            }
          >
            Contact Administrator
          </Button>
        </div>
      </div>
    </div>
  );
}
