import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Shield,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  Download,
  Upload,
  RefreshCw,
  Bell,
  Filter,
  Search,
  Plus,
  Eye,
  Edit,
  Archive,
  Award,
  AlertCircle,
  Zap,
  Globe,
  TrendingUp,
  Database,
  Settings,
  Target,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Layout } from "../components/Layout";
import { COMPANY_INFO } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

export default function Compliance() {
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const handleUploadDocument = () => {
    alert(
      "📤 Upload Compliance Document\n\nSupported formats:\n• PDF (certificates, reports)\n• JPG/PNG (scanned documents)\n• DOC/DOCX (applications)\n\nFeatures:\n• Automatic OCR processing\n• Digital signature validation\n• Metadata extraction\n• Version control\n• Secure cloud storage",
    );
  };

  const handleAddCertificate = () => {
    alert(
      "📋 Add New Certificate\n\nCreate certificate profile:\n\n• Certificate details\n• Issuing authority\n• Validity period\n• Renewal requirements\n• Market applicability\n• Document uploads\n• Auto-renewal settings\n• Notification preferences",
    );
  };

  const handleSetupCompliance = () => {
    alert(
      "⚙️ Setup Compliance System\n\nGet started with:\n\n• Certificate inventory setup\n• Renewal workflow configuration\n• Notification preferences\n• Market requirement mapping\n• Authority contact information\n• Document management\n• Automated reminders\n• Compliance reporting",
    );
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Shield className="mr-3 h-8 w-8 text-blue-600" />
              Compliance Center
            </h1>
            <p className="text-gray-600 mt-1">
              Certificate management and regulatory compliance for{" "}
              {COMPANY_INFO.name}
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Database className="w-4 h-4 mr-2" />
              Ready for Setup
            </Badge>
            <Button variant="outline" onClick={handleUploadDocument}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Document
            </Button>
            <Button
              className="bg-blue-600 text-white hover:bg-blue-700"
              onClick={handleAddCertificate}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Certificate
            </Button>
          </div>
        </motion.div>

        {/* Compliance Overview - Empty State */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Active Certificates
                </CardTitle>
                <CheckCircle className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Plus className="h-4 w-4 mr-1" />
                  Add certificates
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Expiring Soon
                </CardTitle>
                <Clock className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Bell className="h-4 w-4 mr-1" />
                  Setup reminders
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Market Coverage
                </CardTitle>
                <Globe className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0%</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Target className="h-4 w-4 mr-1" />
                  Configure markets
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Auto Renewals
                </CardTitle>
                <Zap className="h-4 w-4 text-gold-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Settings className="h-4 w-4 mr-1" />
                  Setup automation
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Filters and Search */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 items-center justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700">Filter:</span>
            {["all", "active", "expiring", "expired"].map((filter) => (
              <Button
                key={filter}
                variant={filterStatus === filter ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterStatus(filter)}
                className="capitalize"
              >
                {filter === "all" ? "All Certificates" : filter}
              </Button>
            ))}
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search certificates..."
              className="pl-10 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </motion.div>

        {/* Main Content - Empty State */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Certificates List - Empty */}
          <motion.div
            className="lg:col-span-2"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5 text-blue-600" />
                  Compliance Certificates
                </CardTitle>
                <CardDescription>
                  No certificates configured yet
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Empty State */}
                <div className="text-center py-16">
                  <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Shield className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    No Compliance Certificates
                  </h3>
                  <p className="text-gray-600 mb-8 max-w-md mx-auto">
                    Start by adding your first compliance certificate. Track
                    renewals, manage documents, and stay compliant across all
                    your export markets.
                  </p>

                  <div className="space-y-4">
                    <Button
                      className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3"
                      onClick={handleAddCertificate}
                    >
                      <Plus className="mr-2 h-5 w-5" />
                      Add Your First Certificate
                    </Button>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mt-8">
                      <div className="bg-blue-50 p-4 rounded-lg text-center">
                        <FileText className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-blue-900 mb-1">
                          Track Certificates
                        </h4>
                        <p className="text-sm text-blue-700">
                          Monitor all compliance certificates and their validity
                        </p>
                      </div>

                      <div className="bg-green-50 p-4 rounded-lg text-center">
                        <Bell className="h-8 w-8 text-green-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-green-900 mb-1">
                          Smart Reminders
                        </h4>
                        <p className="text-sm text-green-700">
                          Automated alerts for renewal deadlines and expirations
                        </p>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg text-center">
                        <Globe className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-purple-900 mb-1">
                          Market Compliance
                        </h4>
                        <p className="text-sm text-purple-700">
                          Ensure compliance across all your export markets
                        </p>
                      </div>
                    </div>

                    <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center justify-center">
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
                        <span className="text-sm text-yellow-800">
                          Ready to setup your compliance management system?
                          <button
                            className="ml-1 underline hover:no-underline"
                            onClick={handleSetupCompliance}
                          >
                            Get started now
                          </button>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Right Sidebar */}
          <motion.div
            className="space-y-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            {/* Quick Actions */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📊 Generate Compliance Report\n\nCreate comprehensive reports:\n\n• Compliance status summary\n• Expiry timeline\n• Market coverage analysis\n• Risk assessment\n• Cost analysis\n• Renewal recommendations\n\nFormats: PDF, Excel, PowerPoint",
                      )
                    }
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Generate Report
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🔔 Set Bulk Reminders\n\nConfigure reminders for:\n\n• All certificates\n• Specific markets\n• High priority items\n• Custom date ranges\n\nNotification preferences:\n• Email frequency\n• SMS alerts\n• WhatsApp notifications\n• Slack integration",
                      )
                    }
                  >
                    <Bell className="mr-2 h-4 w-4" />
                    Set Reminders
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📋 Compliance Audit\n\nSchedule compliance audit:\n\n• Internal audit checklist\n• External audit preparation\n• Documentation review\n• Process verification\n• Gap analysis\n• Corrective action plans\n\nNext audit: Schedule your first audit",
                      )
                    }
                  >
                    <Archive className="mr-2 h-4 w-4" />
                    Schedule Audit
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Getting Started */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="mr-2 h-5 w-5 text-gold-600" />
                    Getting Started
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-semibold text-blue-600">
                        1
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Add Certificates
                        </p>
                        <p className="text-xs text-gray-500">
                          Upload existing certificates and documentation
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        2
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Set Reminders
                        </p>
                        <p className="text-xs text-gray-500">
                          Configure renewal notifications and alerts
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        3
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Configure Markets
                        </p>
                        <p className="text-xs text-gray-500">
                          Map certificates to your export markets
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button
                    className="w-full mt-4"
                    onClick={handleSetupCompliance}
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Start Setup
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Important Certificates */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="mr-2 h-5 w-5 text-green-600" />
                    Essential Certificates
                  </CardTitle>
                  <CardDescription>
                    Common export compliance requirements
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      "FSSAI License",
                      "ISO 22000 Certificate",
                      "Halal Certification",
                      "Spice Board Registration",
                      "Export License",
                    ].map((cert, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                        onClick={() =>
                          alert(
                            `📋 ${cert}\n\nThis certificate is commonly required for spice exports. Click 'Add Certificate' to set it up in your compliance system.\n\nTypical requirements:\n• Application process\n• Document submission\n• Inspection procedures\n• Renewal schedules`,
                          )
                        }
                      >
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                          <span className="text-sm text-gray-900">{cert}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          Add
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
