export const COMPANY_INFO = {
  name: "Calicut Spice Traders LLP",
  shortName: "CST",
  tagline: "Authentic Kerala Spices to Global Markets",
  description:
    "Leading spice export company specializing in premium quality cardamom, black pepper, turmeric, and other authentic Kerala spices to international markets.",
  establishedYear: 2019,
  partners: 5,
  headquarters: "Calicut, Kerala, India",

  contact: {
    email: "info@calicutspicetraders.com",
    phone: "+91 495 123 4567",
    whatsapp: "+91 9876543210",
    address: "Spice Market Complex, Calicut, Kerala 673001, India",
  },

  website: {
    main: "https://calicutspicetraders.com",
    workspace: "https://workspace.calicutspicetraders.com",
  },
};

export const PRODUCTS = [
  {
    id: "cardamom",
    name: "Cardamom",
    category: "Premium Spices",
    description: "Finest quality green cardamom from Western Ghats",
    exportVolume: "500+ MT/year",
    image: "🫘",
  },
  {
    id: "black-pepper",
    name: "Black Pepper",
    category: "Premium Spices",
    description: "Bold and aromatic Malabar black pepper",
    exportVolume: "800+ MT/year",
    image: "🌶️",
  },
  {
    id: "turmeric",
    name: "Turmeric",
    category: "Health Spices",
    description: "High curcumin content turmeric powder and fingers",
    exportVolume: "1200+ MT/year",
    image: "🟡",
  },
  {
    id: "ginger",
    name: "Ginger",
    category: "Fresh Spices",
    description: "Fresh and dried ginger with strong aroma",
    exportVolume: "600+ MT/year",
    image: "🫚",
  },
  {
    id: "coriander",
    name: "Coriander",
    category: "Seed Spices",
    description: "Premium coriander seeds and powder",
    exportVolume: "400+ MT/year",
    image: "🌿",
  },
  {
    id: "cumin",
    name: "Cumin",
    category: "Seed Spices",
    description: "Aromatic cumin seeds for global cuisine",
    exportVolume: "300+ MT/year",
    image: "🟤",
  },
  {
    id: "fennel",
    name: "Fennel",
    category: "Seed Spices",
    description: "Sweet fennel seeds with natural oils",
    exportVolume: "250+ MT/year",
    image: "🌱",
  },
  {
    id: "red-chilli",
    name: "Red Chilli",
    category: "Hot Spices",
    description: "Dried red chillies with varying heat levels",
    exportVolume: "700+ MT/year",
    image: "🌶️",
  },
  {
    id: "rice",
    name: "Basmati Rice",
    category: "Grains",
    description: "Premium aromatic basmati rice varieties",
    exportVolume: "2000+ MT/year",
    image: "🌾",
  },
];

export const TARGET_MARKETS = [
  {
    id: "uae",
    name: "United Arab Emirates",
    flag: "🇦🇪",
    specialRequirements: [
      "Halal Certification",
      "Emirates Authority for Standardization",
    ],
    exportVolume: "40%",
    keyProducts: ["Cardamom", "Black Pepper", "Basmati Rice"],
  },
  {
    id: "kuwait",
    name: "Kuwait",
    flag: "����🇼",
    specialRequirements: [
      "Halal Certification",
      "Kuwait Municipality Approval",
    ],
    exportVolume: "25%",
    keyProducts: ["Turmeric", "Red Chilli", "Coriander"],
  },
  {
    id: "uk",
    name: "United Kingdom",
    flag: "🇬🇧",
    specialRequirements: ["UK Food Standards", "Pesticide Residue Testing"],
    exportVolume: "20%",
    keyProducts: ["Organic Turmeric", "Black Pepper", "Ginger"],
  },
  {
    id: "africa",
    name: "African Markets",
    flag: "🌍",
    specialRequirements: ["ECOWAS Standards", "African Union Certification"],
    exportVolume: "15%",
    keyProducts: ["Rice", "Red Chilli", "Cumin"],
  },
];

export const CERTIFICATIONS = [
  {
    id: "fssai",
    name: "FSSAI License",
    description: "Food Safety and Standards Authority of India",
    status: "Active",
    validUntil: "2025-03-15",
    certificate: "FSSAI-12345678901234",
  },
  {
    id: "iso22000",
    name: "ISO 22000:2018",
    description: "Food Safety Management System",
    status: "Active",
    validUntil: "2025-06-20",
    certificate: "ISO22000-CST-2024",
  },
  {
    id: "spice-board",
    name: "Spice Board Registration",
    description: "Ministry of Commerce & Industry, Govt. of India",
    status: "Active",
    validUntil: "2025-12-31",
    certificate: "SB-EXPORT-7890",
  },
  {
    id: "halal",
    name: "Halal Certification",
    description: "Jamiat Ulama-i-Hind Halal Trust",
    status: "Active",
    validUntil: "2025-09-10",
    certificate: "HALAL-CST-2024",
  },
];

export const TEAM_ROLES = [
  "Export Manager",
  "Quality Control Officer",
  "Compliance Officer",
  "Logistics Coordinator",
  "Business Development Manager",
  "Documentation Specialist",
  "Partner",
  "Admin",
];

export const NAVIGATION_ITEMS = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: "LayoutDashboard",
  },
  {
    label: "CRM & Sales",
    href: "/crm",
    icon: "Building",
  },
  {
    label: "Exports",
    href: "/exports",
    icon: "Ship",
  },
  {
    label: "Documents",
    href: "/documents",
    icon: "FileText",
  },
  {
    label: "Team",
    href: "/team",
    icon: "Users",
  },
  {
    label: "Compliance",
    href: "/compliance",
    icon: "Shield",
  },
  {
    label: "Analytics",
    href: "/analytics",
    icon: "BarChart3",
  },
  {
    label: "Communication",
    href: "/communication",
    icon: "MessageSquare",
  },
];

export const ADMIN_NAVIGATION_ITEMS = [
  {
    label: "User Management",
    href: "/user-management",
    icon: "UserCog",
  },
];
