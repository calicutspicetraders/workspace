import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  MessageSquare,
  Phone,
  Video,
  Mail,
  Send,
  Users,
  Clock,
  CheckCircle,
  AlertCircle,
  Bell,
  Settings,
  Search,
  Plus,
  MoreHorizontal,
  Paperclip,
  Smile,
  Calendar,
  Database,
  Activity,
  UserPlus,
  Zap,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Layout } from "../components/Layout";
import { COMPANY_INFO } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

export default function Communication() {
  const [messageInput, setMessageInput] = useState("");

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      alert(
        `📤 Message Ready to Send\n\n"${messageInput}"\n\nThis would be sent through the integrated communication system with:\n\n• Real-time delivery\n• Read receipts\n• File sharing support\n• Mobile notifications\n\nConnect your team to start messaging!`,
      );
      setMessageInput("");
    }
  };

  const handleSetupIntegrations = () => {
    alert(
      "⚙️ Setup Communication Integrations\n\nAvailable integrations:\n\n📱 WhatsApp Business API\n🔗 Slack Workspace\n📧 Email Automation\n🎥 Video Conferencing (Jitsi Meet)\n💬 Microsoft Teams\n📞 VoIP Systems\n\nChoose your preferred communication tools to get started",
    );
  };

  const handleAddTeamMember = () => {
    alert(
      "👥 Add Team Member\n\nInvite team members to join:\n\n• Send email invitations\n• Set role and permissions\n• Configure notification preferences\n• Setup communication channels\n• Add to relevant groups\n\nStart building your communication hub!",
    );
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <MessageSquare className="mr-3 h-8 w-8 text-green-600" />
              Communication Hub
            </h1>
            <p className="text-gray-600 mt-1">
              Integrated team communication and customer engagement for{" "}
              {COMPANY_INFO.name}
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Database className="w-4 h-4 mr-2" />
              Ready to Connect
            </Badge>
            <Button variant="outline" onClick={handleSetupIntegrations}>
              <Settings className="mr-2 h-4 w-4" />
              Setup
            </Button>
            <Button
              className="bg-green-600 text-white hover:bg-green-700"
              onClick={handleAddTeamMember}
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Add Team Member
            </Button>
          </div>
        </motion.div>

        {/* Communication Overview - Empty State */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  WhatsApp Business
                </CardTitle>
                <MessageSquare className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Settings className="h-4 w-4 mr-1" />
                  Connect WhatsApp API
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Team Messages
                </CardTitle>
                <Users className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <UserPlus className="h-4 w-4 mr-1" />
                  Add team members
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Video Meetings
                </CardTitle>
                <Video className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Calendar className="h-4 w-4 mr-1" />
                  Schedule meetings
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Email Automation
                </CardTitle>
                <Mail className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Zap className="h-4 w-4 mr-1" />
                  Setup automation
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Main Communication Interface - Empty State */}
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Team Members & Contacts - Empty */}
          <motion.div
            className="lg:col-span-1"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg h-[600px]">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Users className="mr-2 h-5 w-5 text-blue-600" />
                    Team
                  </CardTitle>
                  <Badge variant="secondary">0 members</Badge>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input placeholder="Search team..." className="pl-10" />
                </div>
              </CardHeader>
              <CardContent className="flex items-center justify-center h-full">
                <div className="text-center">
                  <Users className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No Team Members
                  </h3>
                  <p className="text-gray-500 mb-4">
                    Start by adding your team members to enable communication
                  </p>
                  <Button onClick={handleAddTeamMember}>
                    <UserPlus className="mr-2 h-4 w-4" />
                    Add First Member
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Chat Interface - Empty */}
          <motion.div
            className="lg:col-span-2"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg h-[600px] flex flex-col">
              <CardHeader className="border-b">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-gray-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">
                        Welcome to Communication Hub
                      </h3>
                      <p className="text-sm text-gray-500">
                        Connect your team to start messaging
                      </p>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <div className="flex-1 p-4 overflow-y-auto flex items-center justify-center">
                <div className="text-center max-w-md">
                  <MessageSquare className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                  <h3 className="text-xl font-medium text-gray-900 mb-2">
                    Start Your First Conversation
                  </h3>
                  <p className="text-gray-500 mb-6">
                    Add team members and set up integrations to enable real-time
                    communication, file sharing, and collaboration.
                  </p>
                  <div className="space-y-3">
                    <Button
                      onClick={handleAddTeamMember}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      <UserPlus className="mr-2 h-4 w-4" />
                      Add Team Members
                    </Button>
                    <Button
                      onClick={handleSetupIntegrations}
                      variant="outline"
                      className="w-full"
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      Setup Integrations
                    </Button>
                  </div>
                </div>
              </div>

              <div className="border-t p-4">
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" disabled>
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <div className="flex-1 relative">
                    <Input
                      placeholder="Type your message..."
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyPress={(e) =>
                        e.key === "Enter" && handleSendMessage()
                      }
                      disabled
                    />
                  </div>
                  <Button variant="outline" size="sm" disabled>
                    <Smile className="h-4 w-4" />
                  </Button>
                  <Button disabled onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  Add team members to enable messaging
                </p>
              </div>
            </Card>
          </motion.div>

          {/* Right Sidebar - Empty */}
          <motion.div
            className="lg:col-span-1 space-y-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            {/* Integrations */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Available Integrations</CardTitle>
                  <CardDescription>
                    Connect your communication tools
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div
                      className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() =>
                        alert(
                          "💬 WhatsApp Business API\n\nProfessional customer communication:\n\n• Automated order confirmations\n• Shipment tracking updates\n• Customer support tickets\n• Bulk messaging campaigns\n• Template messages\n• Rich media sharing\n• Business profile verification",
                        )
                      }
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-lg">💬</span>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            WhatsApp Business
                          </p>
                          <p className="text-xs text-gray-500">
                            Customer communication
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline">Connect</Badge>
                    </div>

                    <div
                      className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() =>
                        alert(
                          "📱 Slack Integration\n\nTeam collaboration:\n\n• 5 active channels\n• Real-time notifications\n• File sharing\n• Workflow automation\n• Mobile app sync",
                        )
                      }
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-lg">📱</span>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            Slack Workspace
                          </p>
                          <p className="text-xs text-gray-500">
                            Team collaboration
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline">Connect</Badge>
                    </div>

                    <div
                      className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() =>
                        alert(
                          "📧 Email Automation\n\nProfessional email workflows:\n\n• Automated confirmations\n• Customer notifications\n• Team updates\n• Scheduled campaigns",
                        )
                      }
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-lg">📧</span>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            Email Integration
                          </p>
                          <p className="text-xs text-gray-500">
                            Automated workflows
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline">Connect</Badge>
                    </div>

                    <div
                      className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() =>
                        alert(
                          "🎥 Video Meetings\n\nJitsi Meet integration:\n\n• HD video quality\n• Screen sharing\n• Recording capabilities\n• Mobile compatibility",
                        )
                      }
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-lg">🎥</span>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            Video Conferencing
                          </p>
                          <p className="text-xs text-gray-500">
                            Jitsi Meet integration
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline">Setup</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Getting Started */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="mr-2 h-5 w-5 text-green-600" />
                    Getting Started
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-semibold text-blue-600">
                        1
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Add Team Members
                        </p>
                        <p className="text-xs text-gray-500">
                          Invite your team to join the communication hub
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        2
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Setup Integrations
                        </p>
                        <p className="text-xs text-gray-500">
                          Connect WhatsApp, Slack, and other tools
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                        3
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Configure Workflows
                        </p>
                        <p className="text-xs text-gray-500">
                          Set up automated notifications and responses
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button
                    className="w-full mt-4"
                    onClick={handleSetupIntegrations}
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Start Setup
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
