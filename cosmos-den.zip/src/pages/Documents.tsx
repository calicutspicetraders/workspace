import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  FileText,
  Upload,
  Download,
  Search,
  Filter,
  Folder,
  FolderOpen,
  File,
  Image,
  FileSpreadsheet,
  FileImage,
  Plus,
  Share2,
  Eye,
  Edit,
  Trash2,
  Clock,
  User,
  Calendar,
  Shield,
  CheckCircle,
  AlertTriangle,
  Star,
  Archive,
  RefreshCw,
  Tag,
  Link,
  Copy,
  MoreHorizontal,
  Settings,
  BarChart3,
  Database,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Layout } from "../components/Layout";
import { COMPANY_INFO } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

// Document folders structure - ready for real data
const documentFolders = [
  {
    id: "certificates",
    name: "Certificates & Licenses",
    description: "All compliance certificates and official licenses",
    icon: Shield,
    count: 0,
    color: "bg-green-500",
  },
  {
    id: "export-docs",
    name: "Export Documentation",
    description: "Shipping manifests, invoices, and export papers",
    icon: FileText,
    count: 0,
    color: "bg-blue-500",
  },
  {
    id: "quality",
    name: "Quality Reports",
    description: "Quality inspection reports and test certificates",
    icon: CheckCircle,
    count: 0,
    color: "bg-purple-500",
  },
  {
    id: "contracts",
    name: "Contracts & Agreements",
    description: "Customer contracts and vendor agreements",
    icon: File,
    count: 0,
    color: "bg-orange-500",
  },
  {
    id: "financial",
    name: "Financial Documents",
    description: "Invoices, payments, and financial records",
    icon: FileSpreadsheet,
    count: 0,
    color: "bg-gold-500",
  },
  {
    id: "compliance",
    name: "Compliance Documentation",
    description: "Regulatory filings and compliance reports",
    icon: Archive,
    count: 0,
    color: "bg-red-500",
  },
];

export default function Documents() {
  console.log("📄 Documents Management System - Clean version loaded");

  const [selectedFolder, setSelectedFolder] = useState(documentFolders[0]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [viewMode, setViewMode] = useState("grid");

  const handleUploadDocument = () => {
    alert(
      "📤 Upload Document\n\nSupported features:\n\n• Drag & drop upload\n• Multiple file selection\n• Format support: PDF, DOC, XLS, JPG, PNG\n• Automatic file scanning\n• OCR text extraction\n• Metadata capture\n• Version control\n• Secure encryption\n• Access permissions\n• Workflow assignment",
    );
  };

  const handleCreateFolder = () => {
    alert(
      "📁 Create New Folder\n\nOrganize documents with:\n\n• Custom folder structure\n• Access permissions\n• Sharing settings\n• Workflow automation\n• Auto-categorization rules\n• Retention policies\n• Compliance templates\n• Team collaboration\n• Integration with export processes",
    );
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <FileText className="mr-3 h-8 w-8 text-blue-600" />
              Document Management
            </h1>
            <p className="text-gray-600 mt-1">
              Secure document sharing and workflow automation for{" "}
              {COMPANY_INFO.name}
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Database className="w-4 h-4 mr-2" />
              Ready for Documents
            </Badge>
            <Button variant="outline" onClick={handleCreateFolder}>
              <Folder className="mr-2 h-4 w-4" />
              New Folder
            </Button>
            <Button
              className="bg-blue-600 text-white hover:bg-blue-700"
              onClick={handleUploadDocument}
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload Files
            </Button>
          </div>
        </motion.div>

        {/* Storage Overview */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Storage Used
                </CardTitle>
                <Archive className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0 GB</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Database className="h-4 w-4 mr-1" />
                  Ready for uploads
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Documents
                </CardTitle>
                <FileText className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Upload className="h-4 w-4 mr-1" />
                  Start uploading
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Active Workflows
                </CardTitle>
                <RefreshCw className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Settings className="h-4 w-4 mr-1" />
                  Setup workflows
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Security Score
                </CardTitle>
                <Shield className="h-4 w-4 text-gold-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">100%</div>
                <div className="flex items-center text-sm text-gold-600 mt-1">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  System ready
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 items-center justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700">Filter:</span>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Documents</option>
              <option value="pdf">PDF Files</option>
              <option value="docx">Word Documents</option>
              <option value="xlsx">Spreadsheets</option>
              <option value="shared">Shared Documents</option>
              <option value="secured">Secured Documents</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search documents and tags..."
                className="pl-10 w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
            >
              {viewMode === "grid" ? "List View" : "Grid View"}
            </Button>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Document Folders */}
          <motion.div
            className="lg:col-span-1"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Folder className="mr-2 h-5 w-5 text-blue-600" />
                  Document Folders
                </CardTitle>
                <CardDescription>Organized by category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {documentFolders.map((folder) => {
                    const Icon = folder.icon;
                    return (
                      <div
                        key={folder.id}
                        className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors hover:bg-gray-50 ${
                          selectedFolder.id === folder.id
                            ? "bg-blue-50 border border-blue-200"
                            : ""
                        }`}
                        onClick={() => setSelectedFolder(folder)}
                      >
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-8 h-8 ${folder.color} rounded-lg flex items-center justify-center`}
                          >
                            <Icon className="h-4 w-4 text-white" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {folder.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              {folder.count} files
                            </p>
                          </div>
                        </div>
                        <FolderOpen className="h-4 w-4 text-gray-400" />
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Documents List - Empty State */}
          <motion.div
            className="lg:col-span-2"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <FolderOpen className="mr-2 h-5 w-5 text-blue-600" />
                      {selectedFolder.name}
                    </CardTitle>
                    <CardDescription>
                      {selectedFolder.description}
                    </CardDescription>
                  </div>
                  <Badge variant="outline">0 files</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {/* Empty State */}
                <div className="text-center py-16">
                  <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <FileText className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    No Documents Yet
                  </h3>
                  <p className="text-gray-600 mb-8 max-w-md mx-auto">
                    Start by uploading your first document to this folder.
                    Organize certificates, export documents, and quality reports
                    all in one secure place.
                  </p>

                  <div className="space-y-4">
                    <Button
                      className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3"
                      onClick={handleUploadDocument}
                    >
                      <Upload className="mr-2 h-5 w-5" />
                      Upload Your First Document
                    </Button>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mt-8">
                      <div className="bg-blue-50 p-4 rounded-lg text-center">
                        <Shield className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-blue-900 mb-1">
                          Secure Storage
                        </h4>
                        <p className="text-sm text-blue-700">
                          Encrypted storage with access controls and audit
                          trails
                        </p>
                      </div>

                      <div className="bg-green-50 p-4 rounded-lg text-center">
                        <RefreshCw className="h-8 w-8 text-green-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-green-900 mb-1">
                          Smart Workflows
                        </h4>
                        <p className="text-sm text-green-700">
                          Automated approval processes and notification systems
                        </p>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg text-center">
                        <Share2 className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-purple-900 mb-1">
                          Easy Sharing
                        </h4>
                        <p className="text-sm text-purple-700">
                          Share with team members and external partners securely
                        </p>
                      </div>
                    </div>

                    <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center justify-center">
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
                        <span className="text-sm text-yellow-800">
                          Ready to connect with your document management system?
                          <button className="ml-1 underline hover:no-underline">
                            View setup guide
                          </button>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Right Sidebar */}
          <motion.div
            className="space-y-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            {/* Quick Actions */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🔍 Advanced Search\n\nPowerful search capabilities:\n\n• Full-text search inside documents\n• Metadata search\n• Tag-based filtering\n• Date range queries\n• File type filters\n• User activity search\n• Workflow status search\n• Custom saved searches",
                      )
                    }
                  >
                    <Search className="mr-2 h-4 w-4" />
                    Advanced Search
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "📊 Document Analytics\n\nInsights and reporting:\n\n• Usage statistics\n• Storage analytics\n• Workflow performance\n• User activity reports\n• Compliance tracking\n• Version history analysis\n• Security audit logs\n• Custom reports",
                      )
                    }
                  >
                    <BarChart3 className="mr-2 h-4 w-4" />
                    View Analytics
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() =>
                      alert(
                        "🔧 System Settings\n\nConfiguration options:\n\n• Storage settings\n• Security policies\n• Retention rules\n• Access permissions\n• Workflow templates\n• Integration settings\n• Backup configuration\n• User preferences",
                      )
                    }
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Getting Started */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="mr-2 h-5 w-5 text-gold-600" />
                    Getting Started
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
                      <Upload className="h-4 w-4 text-blue-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Upload Documents
                        </p>
                        <p className="text-xs text-gray-500">
                          Start with certificates
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
                      <Folder className="h-4 w-4 text-green-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Organize Folders
                        </p>
                        <p className="text-xs text-gray-500">
                          Create custom structure
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
                      <RefreshCw className="h-4 w-4 text-purple-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Setup Workflows
                        </p>
                        <p className="text-xs text-gray-500">
                          Automate approvals
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
