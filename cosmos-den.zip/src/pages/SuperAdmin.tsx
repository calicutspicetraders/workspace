import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Settings,
  Plug,
  Download,
  Upload,
  Shield,
  Zap,
  CheckCircle,
  AlertTriangle,
  Clock,
  Star,
  Cpu,
  Database,
  Cloud,
  Smartphone,
  Brain,
  CreditCard,
  Truck,
  Building,
  BarChart3,
  Globe,
  Lock,
  Wifi,
  Search,
  Filter,
  Plus,
  Play,
  Pause,
  Trash2,
  Edit,
  Eye,
  RefreshCw,
  Package,
  Layers,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Switch } from "../components/ui/switch";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Layout } from "../components/Layout";
import {
  IntegrationManager,
  BUSINESS_INTEGRATIONS,
  LOGISTICS_INTEGRATIONS,
  FINANCIAL_INTEGRATIONS,
  AI_INTEGRATIONS,
  MOBILE_IOT_INTEGRATIONS,
  AVAILABLE_PLUGINS,
  INTEGRATION_CATEGORIES,
  INTEGRATION_ROADMAP,
  type Integration,
  type Plugin,
} from "../lib/integrations";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

export default function SuperAdmin() {
  const [integrationManager] = useState(new IntegrationManager());
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("integrations");

  const allIntegrations = integrationManager.getAvailableIntegrations();
  const filteredIntegrations = allIntegrations.filter((integration) => {
    const matchesCategory =
      selectedCategory === "all" || integration.category === selectedCategory;
    const matchesSearch =
      integration.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      integration.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-700 border-green-200";
      case "beta":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "coming_soon":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "enterprise":
        return "bg-purple-100 text-purple-700 border-purple-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "text-red-600";
      case "high":
        return "text-orange-600";
      case "medium":
        return "text-yellow-600";
      case "low":
        return "text-green-600";
      default:
        return "text-gray-600";
    }
  };

  const getComplexityIcon = (complexity: string) => {
    switch (complexity) {
      case "easy":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "medium":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "advanced":
        return <AlertTriangle className="h-4 w-4 text-orange-500" />;
      case "expert":
        return <Shield className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    const iconMap: Record<string, React.ReactNode> = {
      "ERP Systems": <Building className="h-5 w-5" />,
      Accounting: <BarChart3 className="h-5 w-5" />,
      Shipping: <Truck className="h-5 w-5" />,
      Customs: <Shield className="h-5 w-5" />,
      Payments: <CreditCard className="h-5 w-5" />,
      Banking: <Building className="h-5 w-5" />,
      "AI Assistant": <Brain className="h-5 w-5" />,
      "AI Processing": <Cpu className="h-5 w-5" />,
      "AI Analytics": <BarChart3 className="h-5 w-5" />,
      Mobile: <Smartphone className="h-5 w-5" />,
      IoT: <Wifi className="h-5 w-5" />,
      Security: <Lock className="h-5 w-5" />,
      Compliance: <Shield className="h-5 w-5" />,
      Localization: <Globe className="h-5 w-5" />,
      Analytics: <BarChart3 className="h-5 w-5" />,
    };
    return iconMap[category] || <Package className="h-5 w-5" />;
  };

  const handleInstallIntegration = async (integration: Integration) => {
    const success = await integrationManager.installIntegration(
      integration.id,
      integration.configOptions,
    );
    if (success) {
      alert(
        `✅ Integration Installed: ${integration.name}\n\n📋 Configuration Required:\n${Object.keys(
          integration.configOptions,
        )
          .map((key) => `• ${key}: ${integration.configOptions[key]}`)
          .join(
            "\n",
          )}\n\n🚀 Features Available:\n${integration.benefits.join("\n• ")}\n\nPlease configure the integration in the settings panel.`,
      );
    } else {
      alert(`❌ Failed to install ${integration.name}. Please try again.`);
    }
  };

  const handleEnablePlugin = async (plugin: Plugin) => {
    const success = await integrationManager.enablePlugin(plugin.id);
    if (success) {
      alert(
        `✅ Plugin Enabled: ${plugin.name}\n\nVersion: ${plugin.version}\nCategory: ${plugin.category}\n\n🔧 Permissions Granted:\n${plugin.permissions.join("\n• ")}\n\n🎯 Available Hooks:\n${plugin.hooks.join("\n• ")}\n\nThe plugin is now active and ready to use.`,
      );
    } else {
      alert(`❌ Failed to enable ${plugin.name}. Please check requirements.`);
    }
  };

  const renderIntegrationsTab = () => (
    <div className="space-y-6">
      {/* Integration Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Total Integrations
            </CardTitle>
            <Plug className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {allIntegrations.length}
            </div>
            <div className="flex items-center text-sm text-blue-600 mt-1">
              <Package className="h-4 w-4 mr-1" />
              Available for install
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Ready to Install
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {
                allIntegrations.filter(
                  (i) => i.status === "available" || i.status === "beta",
                ).length
              }
            </div>
            <div className="flex items-center text-sm text-green-600 mt-1">
              <Download className="h-4 w-4 mr-1" />
              Installation ready
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Critical Priority
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {allIntegrations.filter((i) => i.priority === "critical").length}
            </div>
            <div className="flex items-center text-sm text-red-600 mt-1">
              <Zap className="h-4 w-4 mr-1" />
              High impact
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              AI Powered
            </CardTitle>
            <Brain className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {AI_INTEGRATIONS.length}
            </div>
            <div className="flex items-center text-sm text-purple-600 mt-1">
              <Cpu className="h-4 w-4 mr-1" />
              AI integrations
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-sm font-medium text-gray-700">Category:</span>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-1 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Categories</option>
            {Object.keys(INTEGRATION_CATEGORIES).map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search integrations..."
            className="pl-10 w-64"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Integration Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredIntegrations.map((integration) => (
          <Card
            key={integration.id}
            className="border-0 shadow-lg hover:shadow-xl transition-shadow"
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    {getCategoryIcon(integration.category)}
                  </div>
                  <div>
                    <CardTitle className="text-lg">
                      {integration.name}
                    </CardTitle>
                    <CardDescription>{integration.category}</CardDescription>
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-2">
                  <Badge className={getStatusColor(integration.status)}>
                    {integration.status.replace("_", " ").toUpperCase()}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    <Star
                      className={`h-4 w-4 ${getPriorityColor(integration.priority)}`}
                    />
                    <span
                      className={`text-xs font-medium ${getPriorityColor(integration.priority)}`}
                    >
                      {integration.priority.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">{integration.description}</p>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    {getComplexityIcon(integration.complexity)}
                    <span className="text-sm font-medium">
                      {integration.complexity.charAt(0).toUpperCase() +
                        integration.complexity.slice(1)}{" "}
                      Setup
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-600">
                      {integration.estimatedTime}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Database className="h-4 w-4 text-green-500" />
                    <span className="text-sm font-medium">Features</span>
                  </div>
                  <div className="text-xs text-gray-600">
                    {integration.benefits.length} benefits included
                  </div>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <h4 className="text-sm font-semibold text-gray-900">
                  Key Benefits:
                </h4>
                <div className="grid grid-cols-1 gap-1">
                  {integration.benefits.slice(0, 3).map((benefit, index) => (
                    <div
                      key={index}
                      className="flex items-center space-x-2 text-xs text-gray-600"
                    >
                      <CheckCircle className="h-3 w-3 text-green-500" />
                      <span>{benefit}</span>
                    </div>
                  ))}
                  {integration.benefits.length > 3 && (
                    <div className="text-xs text-gray-500">
                      +{integration.benefits.length - 3} more benefits
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex space-x-2">
                  {integration.realTimeSupport && (
                    <Badge variant="outline" className="text-xs">
                      <Zap className="h-3 w-3 mr-1" />
                      Real-time
                    </Badge>
                  )}
                  {integration.mobileSupport && (
                    <Badge variant="outline" className="text-xs">
                      <Smartphone className="h-3 w-3 mr-1" />
                      Mobile
                    </Badge>
                  )}
                  {integration.webhookSupport && (
                    <Badge variant="outline" className="text-xs">
                      <Wifi className="h-3 w-3 mr-1" />
                      Webhooks
                    </Badge>
                  )}
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      alert(
                        `📋 Integration Details: ${integration.name}\n\n📊 Configuration Options:\n${Object.entries(
                          integration.configOptions,
                        )
                          .map(([key, type]) => `• ${key}: ${type}`)
                          .join(
                            "\n",
                          )}\n\n🔗 API Endpoints:\n${(integration.apiEndpoints || ["None"]).join("\n• ")}\n\n�� Dependencies:\n${integration.dependencies.join("\n• ")}\n\nEstimated Setup Time: ${integration.estimatedTime}`,
                      )
                    }
                  >
                    <Eye className="h-3 w-3 mr-1" />
                    Details
                  </Button>
                  {(integration.status === "available" ||
                    integration.status === "beta") && (
                    <Button
                      size="sm"
                      className="bg-blue-600 text-white hover:bg-blue-700"
                      onClick={() => handleInstallIntegration(integration)}
                    >
                      <Download className="h-3 w-3 mr-1" />
                      Install
                    </Button>
                  )}
                  {integration.status === "coming_soon" && (
                    <Button size="sm" disabled>
                      <Clock className="h-3 w-3 mr-1" />
                      Coming Soon
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderPluginsTab = () => (
    <div className="space-y-6">
      {/* Plugin Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Available Plugins
            </CardTitle>
            <Layers className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {AVAILABLE_PLUGINS.length}
            </div>
            <div className="flex items-center text-sm text-purple-600 mt-1">
              <Package className="h-4 w-4 mr-1" />
              Ready to enable
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Enabled Plugins
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {AVAILABLE_PLUGINS.filter((p) => p.enabled).length}
            </div>
            <div className="flex items-center text-sm text-green-600 mt-1">
              <Play className="h-4 w-4 mr-1" />
              Currently active
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Configurable
            </CardTitle>
            <Settings className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {AVAILABLE_PLUGINS.filter((p) => p.configurable).length}
            </div>
            <div className="flex items-center text-sm text-orange-600 mt-1">
              <Edit className="h-4 w-4 mr-1" />
              Custom settings
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Categories
            </CardTitle>
            <Filter className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {new Set(AVAILABLE_PLUGINS.map((p) => p.category)).size}
            </div>
            <div className="flex items-center text-sm text-gray-600 mt-1">
              <Layers className="h-4 w-4 mr-1" />
              Plugin types
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Plugin Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {AVAILABLE_PLUGINS.map((plugin) => (
          <Card
            key={plugin.id}
            className="border-0 shadow-lg hover:shadow-xl transition-shadow"
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    {getCategoryIcon(plugin.category)}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{plugin.name}</CardTitle>
                    <CardDescription>
                      {plugin.category} • v{plugin.version}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch checked={plugin.enabled} />
                  {plugin.configurable && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        alert(
                          `⚙️ Plugin Configuration: ${plugin.name}\n\n📋 Requirements:\n${plugin.requirements.join("\n• ")}\n\n🔐 Permissions:\n${plugin.permissions.join("\n• ")}\n\n🎣 Available Hooks:\n${plugin.hooks.join("\n• ")}\n\nAuthor: ${plugin.author}`,
                        )
                      }
                    >
                      <Settings className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">{plugin.description}</p>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">
                    Permissions:
                  </h4>
                  <div className="space-y-1">
                    {plugin.permissions.slice(0, 2).map((permission, index) => (
                      <div
                        key={index}
                        className="flex items-center space-x-2 text-xs text-gray-600"
                      >
                        <Lock className="h-3 w-3 text-gray-500" />
                        <span>{permission}</span>
                      </div>
                    ))}
                    {plugin.permissions.length > 2 && (
                      <div className="text-xs text-gray-500">
                        +{plugin.permissions.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">
                    Hooks:
                  </h4>
                  <div className="space-y-1">
                    {plugin.hooks.slice(0, 2).map((hook, index) => (
                      <div
                        key={index}
                        className="flex items-center space-x-2 text-xs text-gray-600"
                      >
                        <Zap className="h-3 w-3 text-yellow-500" />
                        <span>{hook}</span>
                      </div>
                    ))}
                    {plugin.hooks.length > 2 && (
                      <div className="text-xs text-gray-500">
                        +{plugin.hooks.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-xs text-gray-500">by {plugin.author}</div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      alert(
                        `📦 Plugin Assets: ${plugin.name}\n\n📂 Included Files:\n${(plugin.assets || ["No assets"]).join("\n• ")}\n\n📋 Requirements:\n${plugin.requirements.join("\n• ")}\n\nVersion: ${plugin.version}\nAuthor: ${plugin.author}`,
                      )
                    }
                  >
                    <Eye className="h-3 w-3 mr-1" />
                    View
                  </Button>
                  {plugin.enabled ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        alert(`Plugin ${plugin.name} has been disabled.`)
                      }
                    >
                      <Pause className="h-3 w-3 mr-1" />
                      Disable
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="bg-purple-600 text-white hover:bg-purple-700"
                      onClick={() => handleEnablePlugin(plugin)}
                    >
                      <Play className="h-3 w-3 mr-1" />
                      Enable
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderRoadmapTab = () => (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="mr-2 h-5 w-5 text-blue-600" />
            Integration Roadmap
          </CardTitle>
          <CardDescription>
            Planned integration timeline for the next 12 months
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {Object.entries(INTEGRATION_ROADMAP).map(
              ([quarter, integrations]) => (
                <div key={quarter} className="border-l-2 border-blue-200 pl-6">
                  <div className="relative">
                    <div className="absolute -left-9 w-4 h-4 bg-blue-500 rounded-full border-2 border-white"></div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {quarter.replace("_", " ")}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {integrations.map((integration, index) => (
                        <div
                          key={index}
                          className="bg-blue-50 border border-blue-200 rounded-lg p-3 hover:bg-blue-100 transition-colors cursor-pointer"
                          onClick={() =>
                            alert(
                              `🗓️ ${integration} Integration\n\nScheduled for: ${quarter.replace("_", " ")}\n\nThis integration will be available during the specified quarter. Priority and complexity will determine exact release timing.\n\nStay tuned for updates!`,
                            )
                          }
                        >
                          <div className="flex items-center space-x-2">
                            <CheckCircle className="h-4 w-4 text-blue-600" />
                            <span className="text-sm font-medium text-blue-900">
                              {integration}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ),
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Settings className="mr-3 h-8 w-8 text-purple-600" />
              Superadmin Integration Center
            </h1>
            <p className="text-gray-600 mt-1">
              Manage integrations, plugins, and future-ready extensions
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-purple-100 text-purple-700">
              <Shield className="w-4 h-4 mr-2" />
              Admin Access
            </Badge>
            <Button
              variant="outline"
              onClick={() =>
                alert(
                  "🔄 System Refresh\n\nRefreshing integration status and checking for updates...\n\nThis will:\n• Check integration health\n• Update plugin status\n• Sync configuration\n• Validate connections\n• Update roadmap",
                )
              }
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
          </div>
        </motion.div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="integrations" className="flex items-center">
              <Plug className="mr-2 h-4 w-4" />
              Integrations
            </TabsTrigger>
            <TabsTrigger value="plugins" className="flex items-center">
              <Layers className="mr-2 h-4 w-4" />
              Plugins
            </TabsTrigger>
            <TabsTrigger value="roadmap" className="flex items-center">
              <BarChart3 className="mr-2 h-4 w-4" />
              Roadmap
            </TabsTrigger>
          </TabsList>

          <TabsContent value="integrations" className="mt-6">
            {renderIntegrationsTab()}
          </TabsContent>

          <TabsContent value="plugins" className="mt-6">
            {renderPluginsTab()}
          </TabsContent>

          <TabsContent value="roadmap" className="mt-6">
            {renderRoadmapTab()}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
