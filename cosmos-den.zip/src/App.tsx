import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import Index from "./pages/Index";
import Login from "./pages/Login";
import SuperAdminLogin from "./pages/SuperAdminLogin";
import Dashboard from "./pages/Dashboard";
import CRM from "./pages/CRM";
import Exports from "./pages/Exports";
import Analytics from "./pages/Analytics";
import Communication from "./pages/Communication";
import Compliance from "./pages/Compliance";
import Team from "./pages/Team";
import Documents from "./pages/Documents";
import AccountSettings from "./pages/AccountSettings";
import UserManagement from "./pages/UserManagement";
import TestPage from "./pages/TestPage";
import SuperAdmin from "./pages/SuperAdmin";
import NotFound from "./pages/NotFound";
import { Layout } from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";
import { AuthProvider } from "./contexts/AuthContext";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./components/ui/card";
import { Button } from "./components/ui/button";
import "./App.css";

function App() {
  console.log("🚀 App component rendering with routing and authentication");
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/superadmin-login" element={<SuperAdminLogin />} />

          {/* Protected routes - require authentication */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/crm"
            element={
              <ProtectedRoute requiredPermissions={["manage_crm"]}>
                <CRM />
              </ProtectedRoute>
            }
          />
          <Route
            path="/exports"
            element={
              <ProtectedRoute requiredPermissions={["manage_exports"]}>
                <Exports />
              </ProtectedRoute>
            }
          />
          <Route
            path="/analytics"
            element={
              <ProtectedRoute requiredPermissions={["view_analytics"]}>
                <Analytics />
              </ProtectedRoute>
            }
          />
          <Route
            path="/communication"
            element={
              <ProtectedRoute>
                <Communication />
              </ProtectedRoute>
            }
          />
          <Route
            path="/compliance"
            element={
              <ProtectedRoute requiredPermissions={["manage_compliance"]}>
                <Compliance />
              </ProtectedRoute>
            }
          />
          <Route
            path="/team"
            element={
              <ProtectedRoute requiredPermissions={["manage_team"]}>
                <Team />
              </ProtectedRoute>
            }
          />
          <Route
            path="/documents"
            element={
              <ProtectedRoute requiredPermissions={["manage_documents"]}>
                <Documents />
              </ProtectedRoute>
            }
          />
          <Route
            path="/account-settings"
            element={
              <ProtectedRoute>
                <AccountSettings />
              </ProtectedRoute>
            }
          />

          {/* Admin-only routes */}
          <Route
            path="/user-management"
            element={
              <ProtectedRoute adminOnly={true}>
                <UserManagement />
              </ProtectedRoute>
            }
          />

          {/* SuperAdmin-only routes */}
          <Route
            path="/superadmin"
            element={
              <ProtectedRoute superAdminOnly={true}>
                <SuperAdmin />
              </ProtectedRoute>
            }
          />

          {/* Testing route - protected but no specific permissions */}
          <Route
            path="/test"
            element={
              <ProtectedRoute>
                <TestPage />
              </ProtectedRoute>
            }
          />

          {/* Catch-all route for 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

// Placeholder component for future pages
interface PlaceholderPageProps {
  title: string;
  icon: string;
  description: string;
}

function PlaceholderPage({ title, icon, description }: PlaceholderPageProps) {
  return (
    <Layout>
      <div className="p-6">
        <div className="max-w-4xl mx-auto">
          <Card className="border-0 shadow-lg">
            <CardHeader className="text-center pb-8">
              <div className="text-6xl mb-4">{icon}</div>
              <CardTitle className="text-3xl font-bold text-gray-900 mb-2">
                {title}
              </CardTitle>
              <CardDescription className="text-lg">
                {description}
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center pb-8">
              <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
                This module is coming soon as part of the comprehensive digital
                workspace for Calicut Spice Traders LLP. It will provide
                advanced features for managing spice exports to international
                markets.
              </p>

              <div className="space-y-4 mb-8">
                <div className="bg-spice-50 border border-spice-200 rounded-lg p-4">
                  <h4 className="font-semibold text-spice-800 mb-2">
                    Development Status
                  </h4>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-spice-500 h-2 rounded-full"
                      style={{ width: "25%" }}
                    ></div>
                  </div>
                  <p className="text-sm text-spice-700 mt-2">
                    In Progress - 25% Complete
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="outline">
                  <Link to="/dashboard">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Dashboard
                  </Link>
                </Button>
                <Button
                  className="spice-gradient text-white"
                  onClick={() =>
                    alert(
                      `🔔 Get Notified: ${title}\n\nWe'll send you an email notification when this module is ready!\n\nExpected features:\n${description}\n\nEstimated completion: Q2 2024\n\nEmail: admin@calicutspicetraders.com`,
                    )
                  }
                >
                  Get Notified When Ready
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

export default App;
