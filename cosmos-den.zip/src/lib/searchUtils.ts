// Comprehensive search utility for all workspace sections
// This would integrate with your actual database/API in production

export interface SearchResult {
  id: string;
  title: string;
  description: string;
  section: string;
  type: string;
  url: string;
  metadata?: Record<string, any>;
}

export interface SearchFilters {
  section?: string;
  type?: string;
  dateRange?: {
    start: string;
    end: string;
  };
  status?: string;
  market?: string;
}

// Search categories and their searchable fields
export const SEARCH_SECTIONS = {
  crm: {
    name: "CRM & Sales",
    icon: "Building",
    searchableFields: [
      "Customer companies and contacts",
      "Lead information and status",
      "Sales opportunities and deals",
      "Market segments and regions",
      "Revenue and order data",
      "Contact history and communications",
    ],
    types: ["customers", "leads", "opportunities", "orders", "contacts"],
  },
  exports: {
    name: "Export Shipments",
    icon: "Ship",
    searchableFields: [
      "Export numbers and tracking IDs",
      "Customer names and companies",
      "Product types and quantities",
      "Destination countries and ports",
      "Shipping status and timeline",
      "Customs and documentation",
    ],
    types: ["shipments", "orders", "tracking", "customs", "logistics"],
  },
  documents: {
    name: "Documents",
    icon: "FileText",
    searchableFields: [
      "Document names and titles",
      "Certificate numbers and types",
      "File content (OCR searchable)",
      "Tags and metadata",
      "Folder organization",
      "Version history",
    ],
    types: ["certificates", "reports", "contracts", "invoices", "forms"],
  },
  team: {
    name: "Team Members",
    icon: "Users",
    searchableFields: [
      "Employee names and roles",
      "Department assignments",
      "Skills and expertise",
      "Contact information",
      "Performance data",
      "Training records",
    ],
    types: ["employees", "roles", "departments", "skills", "performance"],
  },
  compliance: {
    name: "Compliance",
    icon: "Shield",
    searchableFields: [
      "Certificate names and numbers",
      "Authority information",
      "Expiry dates and renewals",
      "Market requirements",
      "Audit records",
      "Compliance status",
    ],
    types: [
      "certificates",
      "audits",
      "requirements",
      "renewals",
      "authorities",
    ],
  },
  analytics: {
    name: "Analytics",
    icon: "BarChart3",
    searchableFields: [
      "Report names and descriptions",
      "KPIs and metrics",
      "Market performance data",
      "Revenue information",
      "Dashboard content",
      "Trend analysis",
    ],
    types: ["reports", "metrics", "dashboards", "trends", "forecasts"],
  },
  communication: {
    name: "Communication",
    icon: "MessageSquare",
    searchableFields: [
      "Message content and history",
      "Contact conversations",
      "Team communications",
      "Integration data",
      "Email campaigns",
      "Notification logs",
    ],
    types: ["messages", "emails", "calls", "meetings", "campaigns"],
  },
};

// Advanced search operators
export const SEARCH_OPERATORS = {
  exact: '"term"', // Exact phrase match
  exclude: "-term", // Exclude term
  wildcard: "term*", // Wildcard matching
  field: "field:term", // Search specific field
  date: "after:2024-01-01", // Date filtering
  status: "status:active", // Status filtering
  type: "type:customer", // Type filtering
  market: "market:UAE", // Market filtering
};

// Mock search function - replace with actual API call
export async function searchGlobal(
  query: string,
  filters: SearchFilters = {},
): Promise<SearchResult[]> {
  // This would be your actual search API call
  console.log(`🔍 Searching for: "${query}"`, filters);

  // Mock results showing what the search would return
  const mockResults: SearchResult[] = [
    {
      id: "cust-001",
      title: "Al Amal Trading LLC",
      description:
        "Premium spice importer in Dubai, UAE. Active customer since 2022.",
      section: "CRM & Sales",
      type: "customer",
      url: "/crm?customer=cust-001",
      metadata: { market: "UAE", status: "active", revenue: "₹12.5L" },
    },
    {
      id: "exp-2024-001",
      title: "Export EXP-2024-001",
      description: "Cardamom shipment to Dubai - 500 KG, In Transit",
      section: "Export Shipments",
      type: "shipment",
      url: "/exports?id=exp-2024-001",
      metadata: { status: "in-transit", destination: "Dubai", value: "₹8.5L" },
    },
    {
      id: "cert-fssai",
      title: "FSSAI License Certificate",
      description: "Food Safety License - Valid until March 2025",
      section: "Compliance",
      type: "certificate",
      url: "/compliance?cert=fssai",
      metadata: { expiry: "2025-03-15", authority: "FSSAI", status: "active" },
    },
    {
      id: "team-rajesh",
      title: "Rajesh Kumar - Export Manager",
      description: "Senior Export Manager, Operations Department",
      section: "Team Members",
      type: "employee",
      url: "/team?member=rajesh",
      metadata: {
        department: "Operations",
        role: "Export Manager",
        experience: "5 years",
      },
    },
  ];

  // Filter results based on query and filters
  let results = mockResults;

  if (query.trim()) {
    results = results.filter(
      (result) =>
        result.title.toLowerCase().includes(query.toLowerCase()) ||
        result.description.toLowerCase().includes(query.toLowerCase()),
    );
  }

  if (filters.section) {
    results = results.filter((result) =>
      result.section.toLowerCase().includes(filters.section!.toLowerCase()),
    );
  }

  if (filters.type) {
    results = results.filter((result) => result.type === filters.type);
  }

  return results;
}

// Parse search query for advanced operators
export function parseSearchQuery(query: string): {
  terms: string[];
  filters: SearchFilters;
  operators: string[];
} {
  const terms: string[] = [];
  const filters: SearchFilters = {};
  const operators: string[] = [];

  // Extract quoted phrases
  const quotedRegex = /"([^"]+)"/g;
  let match;
  while ((match = quotedRegex.exec(query)) !== null) {
    terms.push(match[1]);
    operators.push("exact");
  }

  // Extract field searches (field:value)
  const fieldRegex = /(\w+):(\w+)/g;
  while ((match = fieldRegex.exec(query)) !== null) {
    const [, field, value] = match;
    switch (field) {
      case "section":
        filters.section = value;
        break;
      case "type":
        filters.type = value;
        break;
      case "status":
        filters.status = value;
        break;
      case "market":
        filters.market = value;
        break;
    }
    operators.push("field");
  }

  // Extract date filters
  const dateRegex = /(after|before):(\d{4}-\d{2}-\d{2})/g;
  while ((match = dateRegex.exec(query)) !== null) {
    const [, operator, date] = match;
    if (!filters.dateRange) filters.dateRange = { start: "", end: "" };
    if (operator === "after") filters.dateRange.start = date;
    if (operator === "before") filters.dateRange.end = date;
    operators.push("date");
  }

  return { terms, filters, operators };
}

// Get search suggestions based on partial query
export function getSearchSuggestions(query: string): string[] {
  const suggestions = [
    // CRM suggestions
    "customers in UAE",
    "active leads",
    "sales pipeline",
    "customer orders",

    // Export suggestions
    "export shipments",
    "cardamom exports",
    "shipments to Dubai",
    "in transit orders",

    // Document suggestions
    "FSSAI certificate",
    "quality reports",
    "export documents",
    "compliance certificates",

    // Team suggestions
    "export manager",
    "team performance",
    "department operations",
    "contact information",

    // General suggestions
    "status:active",
    "market:UAE",
    "type:customer",
    "after:2024-01-01",
  ];

  if (!query.trim()) return suggestions.slice(0, 8);

  return suggestions
    .filter((suggestion) =>
      suggestion.toLowerCase().includes(query.toLowerCase()),
    )
    .slice(0, 8);
}

export default {
  searchGlobal,
  parseSearchQuery,
  getSearchSuggestions,
  SEARCH_SECTIONS,
  SEARCH_OPERATORS,
};
