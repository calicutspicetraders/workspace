import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import {
  LayoutDashboard,
  Ship,
  FileText,
  Users,
  Shield,
  BarChart3,
  MessageSquare,
  Building,
  UserCog,
  Menu,
  X,
  Bell,
  Search,
  User,
  Settings,
  LogOut,
  ChevronDown,
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import {
  COMPANY_INFO,
  NAVIGATION_ITEMS,
  ADMIN_NAVIGATION_ITEMS,
} from "../lib/constants";

const iconMap = {
  LayoutDashboard,
  Building,
  Ship,
  FileText,
  Users,
  Shield,
  BarChart3,
  MessageSquare,
  UserCog,
};

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const isActive = (href: string) => location.pathname === href;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0`}
      >
        {/* Logo */}
        <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 spice-gradient rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">
                {COMPANY_INFO.shortName}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-gray-900">
                {COMPANY_INFO.shortName}
              </span>
              <span className="text-xs text-gray-500">Workspace</span>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="mt-6 px-3">
          <div className="space-y-1">
            {NAVIGATION_ITEMS.map((item) => {
              const Icon = iconMap[item.icon as keyof typeof iconMap];
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                    isActive(item.href)
                      ? "bg-spice-50 text-spice-700 border-r-2 border-spice-500"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  }`}
                  onClick={() => setSidebarOpen(false)}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.label}
                </Link>
              );
            })}

            {/* Admin-only navigation */}
            {user?.role === "admin" && (
              <>
                <div className="border-t border-gray-200 my-4"></div>
                <div className="px-3 py-2">
                  <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                    Administration
                  </span>
                </div>
                {ADMIN_NAVIGATION_ITEMS.map((item) => {
                  const Icon = iconMap[item.icon as keyof typeof iconMap];
                  return (
                    <Link
                      key={item.href}
                      to={item.href}
                      className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                        isActive(item.href)
                          ? "bg-spice-50 text-spice-700 border-r-2 border-spice-500"
                          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                      }`}
                      onClick={() => setSidebarOpen(false)}
                    >
                      <Icon className="mr-3 h-5 w-5" />
                      {item.label}
                    </Link>
                  );
                })}
              </>
            )}
          </div>
        </nav>

        {/* Quick Stats */}
        <div className="mt-8 mx-3">
          <div className="bg-gradient-to-br from-spice-500 to-spice-600 rounded-lg p-4 text-white">
            <h4 className="text-sm font-medium mb-2">Export Status</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Active Shipments</span>
                <span className="font-semibold">0</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Pending Docs</span>
                <span className="font-semibold">0</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>This Month</span>
                <span className="font-semibold">₹0</span>
              </div>
            </div>
          </div>
        </div>

        {/* Support */}
        <div className="absolute bottom-6 left-3 right-3">
          <div className="bg-gold-50 border border-gold-200 rounded-lg p-3">
            <div className="flex items-center mb-2">
              <div className="w-2 h-2 bg-gold-500 rounded-full animate-pulse mr-2"></div>
              <span className="text-xs font-medium text-gold-800">
                Support Available
              </span>
            </div>
            <p className="text-xs text-gold-700 mb-2">
              Need help with exports or compliance?
            </p>
            <Button
              size="sm"
              variant="outline"
              className="w-full text-xs border-gold-300 hover:bg-gold-100"
              onClick={() =>
                alert(
                  "📞 Support Available\n\nContact our expert team:\n\n📧 Email: support@calicutspicetraders.com\n📱 Phone: +91 495 123 4567\n💬 WhatsApp: +91 9876543210\n\n🕐 Hours: Mon-Fri 9AM-6PM IST\n🌐 24/7 Emergency hotline available\n\nWe're here to help with exports, compliance, and technical issues!",
                )
              }
            >
              Contact Support
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:pl-64">
        {/* Top Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between h-16 px-6">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>

              <div className="hidden md:block">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search all sections..."
                    className="pl-10 w-96"
                    onChange={(e) => {
                      const searchTerm = e.target.value;
                      console.log("🔍 Search query:", searchTerm);
                      if (searchTerm.length > 2) {
                        // This would normally trigger search API
                        console.log("Searching for:", searchTerm);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        const searchTerm = (e.target as HTMLInputElement).value;
                        if (searchTerm.trim()) {
                          alert(
                            `🔍 Global Search Results for: "${searchTerm}"\n\nSearching across ALL sections:\n\n🏢 CRM & SALES\n• Customer companies and contacts\n• Lead information and status\n• Sales opportunities and deals\n• Market segments and regions\n\n📦 EXPORT SHIPMENTS\n• Export numbers and tracking IDs\n• Customer names and companies\n• Product types and quantities\n• Destination countries and ports\n• Shipping status and timeline\n\n📄 DOCUMENTS\n• Certificates and licenses\n• Export documentation\n• Quality reports and tests\n• Compliance records\n• Contract agreements\n\n👥 TEAM MEMBERS\n• Employee names and roles\n• Department assignments\n• Skills and expertise\n• Contact information\n• Performance data\n\n🛡️ COMPLIANCE\n• Certificate names and numbers\n• Authority information\n• Expiry dates and renewals\n• Market requirements\n• Audit records\n\n📊 ANALYTICS\n• Report names and data\n• KPIs and metrics\n• Market performance\n• Revenue information\n\n💬 COMMUNICATION\n• Message content and history\n• Contact conversations\n• Team communications\n• Integration data\n\n⚙️ ADVANCED SEARCH:\n• Use quotes for exact phrases: "cardamom export"\n• Filter by section: crm:customers, export:status\n• Date ranges: after:2024-01-01, before:2024-12-31\n• Status filters: active, pending, completed\n• Market filters: UAE, Kuwait, UK, Africa\n\nReal-time search would show instant results as you type across all modules!`,
                          );
                        }
                      }
                    }}
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Notifications */}
              <Button
                variant="ghost"
                size="sm"
                className="relative"
                onClick={() =>
                  alert(
                    "🔔 Notifications\n\n📋 Recent Activities:\n\n• EXP-2024-004 - Documentation completed (2 hours ago)\n• ISO 22000 Certificate - Renewal due in 12 days\n• Export License - Urgent renewal needed (5 days)\n• Quality inspection completed for Cardamom batch\n• Customer inquiry from Dubai received\n• Temperature alert resolved for Container C-123\n\n📊 System Alerts:\n• 2 compliance items need attention\n• 3 shipments require document updates\n• 1 customer payment pending\n\n⚙️ Notification Settings:\n• Real-time alerts: Enabled\n• Email notifications: Enabled\n• SMS alerts: Critical only\n\nClick individual items for details or manage notification preferences in Settings.",
                  )
                }
              >
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-red-500 text-white text-xs">
                  3
                </Badge>
              </Button>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center space-x-2 h-auto p-2"
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.avatar} />
                      <AvatarFallback className="bg-spice-500 text-white">
                        {user?.firstName?.[0]}
                        {user?.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden md:block text-left">
                      <p className="text-sm font-medium">
                        {user?.firstName} {user?.lastName}
                      </p>
                      <p className="text-xs text-gray-500">
                        {user?.role === "admin"
                          ? "Administrator"
                          : user?.department}
                      </p>
                    </div>
                    <ChevronDown className="h-4 w-4 text-gray-500" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => navigate("/account-settings")}
                    className="cursor-pointer"
                  >
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate("/account-settings")}
                    className="cursor-pointer"
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-red-600 cursor-pointer"
                    onClick={() => {
                      if (confirm("Are you sure you want to sign out?")) {
                        logout();
                        navigate("/login");
                      }
                    }}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1">{children}</main>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
