import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: "superadmin" | "admin" | "team_member" | "pending";
  department: string;
  avatar?: string;
  isActive: boolean;
  permissions: string[];
  lastLogin?: string;
  joinedAt: string;
  invitedBy?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isSuperAdmin: boolean;
  isLoading: boolean;
  login: (
    email: string,
    password: string,
  ) => Promise<{ success: boolean; error?: string }>;
  loginSuperAdmin: (
    email: string,
    password: string,
  ) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users database (in a real app, this would be from your backend)
const MOCK_USERS: User[] = [
  {
    id: "0",
    email: "superadmin@calicutspicetraders.com",
    firstName: "System",
    lastName: "SuperAdmin",
    role: "superadmin",
    department: "System Administration",
    isActive: true,
    permissions: [
      "manage_users",
      "manage_exports",
      "manage_compliance",
      "view_analytics",
      "manage_documents",
      "manage_crm",
      "manage_team",
      "view_financials",
      "system_admin",
      "manage_integrations",
      "manage_plugins",
      "system_config",
    ],
    joinedAt: "2024-01-01",
  },
  {
    id: "1",
    email: "admin@calicutspicetraders.com",
    firstName: "Admin",
    lastName: "User",
    role: "admin",
    department: "Administration",
    isActive: true,
    permissions: [
      "manage_users",
      "manage_exports",
      "manage_compliance",
      "view_analytics",
    ],
    joinedAt: "2024-01-01",
  },
  {
    id: "2",
    email: "manager@calicutspicetraders.com",
    firstName: "Export",
    lastName: "Manager",
    role: "team_member",
    department: "International Trade",
    isActive: true,
    permissions: ["manage_exports", "view_analytics", "manage_documents"],
    joinedAt: "2024-01-15",
    invitedBy: "1",
  },
  {
    id: "3",
    email: "quality@calicutspicetraders.com",
    firstName: "Quality",
    lastName: "Inspector",
    role: "team_member",
    department: "Quality Control",
    isActive: true,
    permissions: ["manage_compliance", "manage_documents"],
    joinedAt: "2024-02-01",
    invitedBy: "1",
  },
  {
    id: "4",
    email: "pending@calicutspicetraders.com",
    firstName: "Pending",
    lastName: "User",
    role: "pending",
    department: "Logistics",
    isActive: false,
    permissions: [],
    joinedAt: "2024-03-01",
    invitedBy: "1",
  },
];

// Mock credentials (in a real app, this would be handled by your backend)
const MOCK_CREDENTIALS = [
  { email: "admin@calicutspicetraders.com", password: "admin123" },
  { email: "manager@calicutspicetraders.com", password: "manager123" },
  { email: "quality@calicutspicetraders.com", password: "quality123" },
];

// SuperAdmin credentials (separate and more secure)
const SUPERADMIN_CREDENTIALS = [
  { email: "superadmin@calicutspicetraders.com", password: "superadmin2024" },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    // Check for regular user session
    const savedUser = localStorage.getItem("spice_trader_user");
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        // Verify user still exists and is active
        const currentUser = MOCK_USERS.find(
          (u) =>
            u.id === parsedUser.id && u.isActive && u.role !== "superadmin",
        );
        if (currentUser) {
          setUser(currentUser);
        } else {
          localStorage.removeItem("spice_trader_user");
        }
      } catch (error) {
        localStorage.removeItem("spice_trader_user");
      }
    }

    // Check for SuperAdmin session (separate storage)
    const savedSuperAdmin = localStorage.getItem("spice_trader_superadmin");
    if (savedSuperAdmin) {
      try {
        const parsedUser = JSON.parse(savedSuperAdmin);
        // Verify SuperAdmin still exists and is active
        const currentUser = MOCK_USERS.find(
          (u) =>
            u.id === parsedUser.id && u.isActive && u.role === "superadmin",
        );
        if (currentUser) {
          setUser(currentUser);
        } else {
          localStorage.removeItem("spice_trader_superadmin");
        }
      } catch (error) {
        localStorage.removeItem("spice_trader_superadmin");
      }
    }

    setIsLoading(false);
  }, []);

  const login = async (
    email: string,
    password: string,
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Check credentials
    const credentials = MOCK_CREDENTIALS.find(
      (c) => c.email === email && c.password === password,
    );
    if (!credentials) {
      setIsLoading(false);
      return { success: false, error: "Invalid email or password" };
    }

    // Find user
    const foundUser = MOCK_USERS.find((u) => u.email === email);
    if (!foundUser) {
      setIsLoading(false);
      return { success: false, error: "User not found" };
    }

    if (!foundUser.isActive) {
      setIsLoading(false);
      return {
        success: false,
        error: "Account is not active. Please contact your administrator.",
      };
    }

    if (foundUser.role === "pending") {
      setIsLoading(false);
      return {
        success: false,
        error:
          "Account is pending approval. Please contact your administrator.",
      };
    }

    // Update last login
    const updatedUser = { ...foundUser, lastLogin: new Date().toISOString() };
    setUser(updatedUser);
    localStorage.setItem("spice_trader_user", JSON.stringify(updatedUser));

    setIsLoading(false);
    return { success: true };
  };

  const loginSuperAdmin = async (
    email: string,
    password: string,
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);

    // Simulate API call delay with extra security check
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Check SuperAdmin credentials (more restrictive)
    const credentials = SUPERADMIN_CREDENTIALS.find(
      (c) => c.email === email && c.password === password,
    );
    if (!credentials) {
      setIsLoading(false);
      return { success: false, error: "Invalid SuperAdmin credentials" };
    }

    // Find SuperAdmin user
    const foundUser = MOCK_USERS.find(
      (u) => u.email === email && u.role === "superadmin",
    );
    if (!foundUser) {
      setIsLoading(false);
      return { success: false, error: "SuperAdmin account not found" };
    }

    if (!foundUser.isActive) {
      setIsLoading(false);
      return {
        success: false,
        error: "SuperAdmin account is not active.",
      };
    }

    // Update last login
    const updatedUser = { ...foundUser, lastLogin: new Date().toISOString() };
    setUser(updatedUser);
    localStorage.setItem(
      "spice_trader_superadmin",
      JSON.stringify(updatedUser),
    );

    setIsLoading(false);
    return { success: true };
  };

  const loginWithGoogle = async (): Promise<{
    success: boolean;
    error?: string;
  }> => {
    setIsLoading(true);

    // Simulate Google OAuth flow
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // In a real app, this would handle the Google OAuth response
    // For demo purposes, we'll simulate a successful Google login for the admin
    const mockGoogleEmail = "admin@calicutspicetraders.com";
    const foundUser = MOCK_USERS.find((u) => u.email === mockGoogleEmail);

    if (!foundUser) {
      setIsLoading(false);
      return {
        success: false,
        error:
          "Google account not found in our system. Please contact your administrator.",
      };
    }

    if (!foundUser.isActive) {
      setIsLoading(false);
      return {
        success: false,
        error: "Account is not active. Please contact your administrator.",
      };
    }

    if (foundUser.role === "pending") {
      setIsLoading(false);
      return {
        success: false,
        error:
          "Account is pending approval. Please contact your administrator.",
      };
    }

    const updatedUser = { ...foundUser, lastLogin: new Date().toISOString() };
    setUser(updatedUser);
    localStorage.setItem("spice_trader_user", JSON.stringify(updatedUser));

    setIsLoading(false);
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("spice_trader_user");
    localStorage.removeItem("spice_trader_superadmin");
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem("spice_trader_user", JSON.stringify(updatedUser));
    }
  };

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user && user.isActive && user.role !== "pending",
    isSuperAdmin: !!user && user.isActive && user.role === "superadmin",
    isLoading,
    login,
    loginSuperAdmin,
    loginWithGoogle,
    logout,
    updateUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

export { MOCK_USERS, type AuthContextType };
