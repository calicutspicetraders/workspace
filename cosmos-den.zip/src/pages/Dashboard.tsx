import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Package,
  Truck,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  Globe,
  FileText,
  BarChart3,
  DollarSign,
  Ship,
  Calendar,
  Bell,
  ArrowRight,
  ArrowLeft,
  MapPin,
  Award,
  Shield,
  Database,
  Plus,
  Activity,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Progress } from "../components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Layout } from "../components/Layout";
import { COMPANY_INFO } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

export default function Dashboard() {
  console.log(
    "🎯 Dashboard component loaded - Clean version without mock data",
  );

  const navigate = useNavigate();

  const handleScheduleExport = () => {
    navigate("/exports");
  };

  const handleViewAllShipments = () => {
    navigate("/exports");
  };

  const handleManageCompliance = () => {
    navigate("/compliance");
  };

  const handleViewAnalytics = () => {
    navigate("/analytics");
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/")}
              className="hover:bg-spice-50 hover:border-spice-300"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Export Dashboard
              </h1>
              <p className="text-gray-600 mt-1">
                Welcome to {COMPANY_INFO.name} digital workspace
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Database className="w-4 h-4 mr-2" />
              Ready for Data Integration
            </Badge>
            <Button
              className="spice-gradient text-white"
              onClick={handleScheduleExport}
            >
              <Plus className="mr-2 h-4 w-4" />
              Create Export
            </Button>
          </div>
        </motion.div>

        {/* Key Metrics - Empty State */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Monthly Revenue
                </CardTitle>
                <DollarSign className="h-4 w-4 text-spice-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">₹0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Activity className="h-4 w-4 mr-1" />
                  Connect to view analytics
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Active Shipments
                </CardTitle>
                <Ship className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Truck className="h-4 w-4 mr-1" />
                  No active shipments
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Export Volume
                </CardTitle>
                <Package className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0 MT</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  Ready to track volumes
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="border-0 shadow-lg card-hover">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Compliance Score
                </CardTitle>
                <Award className="h-4 w-4 text-gold-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">--</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Shield className="h-4 w-4 mr-1" />
                  Setup compliance tracking
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Empty State Analytics */}
        <div className="grid lg:grid-cols-3 gap-6">
          <motion.div
            className="lg:col-span-2"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5 text-spice-600" />
                  Export Performance
                </CardTitle>
                <CardDescription>
                  Revenue analytics will appear here once data is connected
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      No Analytics Data
                    </h3>
                    <p className="text-gray-500 mb-4">
                      Connect your data source to view revenue trends and
                      performance metrics
                    </p>
                    <Button onClick={handleViewAnalytics}>
                      Setup Analytics
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial="initial" animate="animate" variants={fadeInUp}>
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="mr-2 h-5 w-5 text-blue-600" />
                  Market Distribution
                </CardTitle>
                <CardDescription>Export analytics by region</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center">
                  <div className="text-center">
                    <Globe className="mx-auto h-8 w-8 text-gray-400 mb-3" />
                    <p className="text-sm text-gray-500 mb-3">
                      Market data will display once exports are recorded
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleScheduleExport}
                    >
                      Create First Export
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Empty State Activity */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Shipments - Empty */}
          <motion.div
            className="lg:col-span-2"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Truck className="mr-2 h-5 w-5 text-blue-600" />
                    Recent Shipments
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleViewAllShipments}
                  >
                    View All
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Truck className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No Shipments Yet
                  </h3>
                  <p className="text-gray-500 mb-6">
                    Start by creating your first export shipment to track
                    deliveries and logistics
                  </p>
                  <Button
                    className="spice-gradient text-white"
                    onClick={handleScheduleExport}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Create First Shipment
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Compliance & Team - Empty */}
          <motion.div
            className="space-y-6"
            initial="initial"
            animate="animate"
            variants={stagger}
          >
            {/* Compliance Status - Empty */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="mr-2 h-5 w-5 text-green-600" />
                    Compliance Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Shield className="mx-auto h-8 w-8 text-gray-400 mb-3" />
                    <p className="text-sm text-gray-500 mb-4">
                      Set up compliance tracking for certificates and renewals
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={handleManageCompliance}
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      Setup Compliance
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Team Activity - Empty */}
            <motion.div variants={fadeInUp}>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="mr-2 h-5 w-5 text-purple-600" />
                    Team Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Users className="mx-auto h-8 w-8 text-gray-400 mb-3" />
                    <p className="text-sm text-gray-500 mb-4">
                      Team activity feed will show recent actions and updates
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => navigate("/team")}
                    >
                      <Bell className="mr-2 h-4 w-4" />
                      View Team Hub
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>

        {/* Quick Actions */}
        <motion.div initial="initial" animate="animate" variants={fadeInUp}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Get started with your export management workspace
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center space-y-2"
                  onClick={handleScheduleExport}
                >
                  <Plus className="h-6 w-6" />
                  <span className="text-sm">New Export</span>
                </Button>
                <Button
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center space-y-2"
                  onClick={() => navigate("/documents")}
                >
                  <FileText className="h-6 w-6" />
                  <span className="text-sm">Documents</span>
                </Button>
                <Button
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center space-y-2"
                  onClick={handleManageCompliance}
                >
                  <Shield className="h-6 w-6" />
                  <span className="text-sm">Compliance</span>
                </Button>
                <Button
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center space-y-2"
                  onClick={() => navigate("/team")}
                >
                  <Users className="h-6 w-6" />
                  <span className="text-sm">Team</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
