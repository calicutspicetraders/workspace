import React, { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

interface ProtectedRouteProps {
  children: ReactNode;
  requiredPermissions?: string[];
  adminOnly?: boolean;
  superAdminOnly?: boolean;
}

export function ProtectedRoute({
  children,
  requiredPermissions = [],
  adminOnly = false,
  superAdminOnly = false,
}: ProtectedRouteProps) {
  const { isAuthenticated, isSuperAdmin, user, isLoading } = useAuth();
  const location = useLocation();

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-spice-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Verifying access...</p>
        </div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Check if user account is active
  if (!user.isActive) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md mx-auto text-center">
          <div className="bg-red-100 border border-red-300 rounded-lg p-6">
            <div className="text-red-600 text-6xl mb-4">🚫</div>
            <h2 className="text-xl font-bold text-red-800 mb-2">
              Account Inactive
            </h2>
            <p className="text-red-700 mb-4">
              Your account has been deactivated. Please contact your
              administrator for assistance.
            </p>
            <p className="text-sm text-red-600">
              Contact: admin@calicutspicetraders.com
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Check if user account is pending approval
  if (user.role === "pending") {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md mx-auto text-center">
          <div className="bg-yellow-100 border border-yellow-300 rounded-lg p-6">
            <div className="text-yellow-600 text-6xl mb-4">⏳</div>
            <h2 className="text-xl font-bold text-yellow-800 mb-2">
              Pending Approval
            </h2>
            <p className="text-yellow-700 mb-4">
              Your account is awaiting approval from an administrator. You'll
              receive an email once your access is granted.
            </p>
            <div className="bg-yellow-50 rounded-lg p-3 mb-4">
              <p className="text-sm text-yellow-700">
                <span className="font-medium">Invited by:</span>{" "}
                {user.invitedBy ? "Administrator" : "System"}
              </p>
              <p className="text-sm text-yellow-700">
                <span className="font-medium">Department:</span>{" "}
                {user.department}
              </p>
              <p className="text-sm text-yellow-700">
                <span className="font-medium">Request Date:</span>{" "}
                {new Date(user.joinedAt).toLocaleDateString()}
              </p>
            </div>
            <p className="text-xs text-yellow-600">
              Contact: admin@calicutspicetraders.com for urgent requests
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Check superadmin-only access
  if (superAdminOnly && user.role !== "superadmin") {
    return (
      <Navigate to="/superadmin-login" state={{ from: location }} replace />
    );
  }

  // Check admin-only access
  if (adminOnly && user.role !== "admin" && user.role !== "superadmin") {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md mx-auto text-center">
          <div className="bg-red-100 border border-red-300 rounded-lg p-6">
            <div className="text-red-600 text-6xl mb-4">🔒</div>
            <h2 className="text-xl font-bold text-red-800 mb-2">
              Access Denied
            </h2>
            <p className="text-red-700 mb-4">
              This area is restricted to administrators only.
            </p>
            <button
              onClick={() => window.history.back()}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
            >
              Go Back
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Check specific permissions
  if (requiredPermissions.length > 0) {
    const hasPermission = requiredPermissions.some((permission) =>
      user.permissions.includes(permission),
    );

    if (!hasPermission) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <div className="max-w-md mx-auto text-center">
            <div className="bg-yellow-100 border border-yellow-300 rounded-lg p-6">
              <div className="text-yellow-600 text-6xl mb-4">⚠️</div>
              <h2 className="text-xl font-bold text-yellow-800 mb-2">
                Insufficient Permissions
              </h2>
              <p className="text-yellow-700 mb-4">
                You don't have the required permissions to access this area.
              </p>
              <div className="bg-yellow-50 rounded-lg p-3 mb-4">
                <p className="text-sm text-yellow-700">
                  <span className="font-medium">Required:</span>{" "}
                  {requiredPermissions.join(", ")}
                </p>
                <p className="text-sm text-yellow-700">
                  <span className="font-medium">Your permissions:</span>{" "}
                  {user.permissions.join(", ") || "None"}
                </p>
              </div>
              <button
                onClick={() => window.history.back()}
                className="bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700 transition-colors"
              >
                Go Back
              </button>
            </div>
          </div>
        </div>
      );
    }
  }

  // All checks passed, render the protected content
  return <>{children}</>;
}

export default ProtectedRoute;
