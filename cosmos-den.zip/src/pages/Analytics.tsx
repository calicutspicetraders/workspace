import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Globe,
  Target,
  Users,
  Package,
  Calendar,
  Download,
  Filter,
  RefreshCw,
  Eye,
  PieChart,
  LineChart,
  Database,
  Activity,
  Settings,
  Plus,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Layout } from "../components/Layout";
import { COMPANY_INFO } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("6M");
  const [selectedMetric, setSelectedMetric] = useState("revenue");

  const handleTimeRangeChange = (range: string) => {
    setTimeRange(range);
    console.log(`📊 Analytics time range changed to: ${range}`);
  };

  const handleMetricChange = (metric: string) => {
    setSelectedMetric(metric);
    console.log(`📈 Analytics metric changed to: ${metric}`);
  };

  const handleExportReport = () => {
    alert(
      "📊 Export Analytics Report\n\nGenerate comprehensive reports:\n\n• Revenue Performance Analysis\n• Market Penetration Reports\n• Product Performance Metrics\n• Export Trend Analysis\n• Customer Insights\n• Compliance Analytics\n\nFormats: PDF, Excel, PowerPoint\nScheduled Reports: Daily, Weekly, Monthly",
    );
  };

  const handleRefreshData = () => {
    alert(
      "🔄 Refreshing Analytics Data\n\nUpdating real-time data from:\n\n• Export Management System\n• Financial Records\n• Customer Database\n• Logistics Partners\n• Market Intelligence\n\nLast updated: " +
        new Date().toLocaleString(),
    );
  };

  const handleSetupAnalytics = () => {
    alert(
      "⚙️ Setup Analytics\n\nConfigure your analytics dashboard:\n\n• Connect data sources\n• Define KPIs and metrics\n• Set up automated reports\n• Configure alerts and thresholds\n• Customize dashboard layout\n• Set user permissions\n\nGet started with the setup wizard",
    );
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <BarChart3 className="mr-3 h-8 w-8 text-purple-600" />
              Business Intelligence
            </h1>
            <p className="text-gray-600 mt-1">
              Advanced analytics and insights for {COMPANY_INFO.name}
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Database className="w-4 h-4 mr-2" />
              Ready for Data
            </Badge>
            <Button variant="outline" onClick={handleRefreshData}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
            <Button
              className="bg-purple-600 text-white hover:bg-purple-700"
              onClick={handleSetupAnalytics}
            >
              <Settings className="mr-2 h-4 w-4" />
              Setup Analytics
            </Button>
          </div>
        </motion.div>

        {/* Time Range Selector */}
        <motion.div
          className="flex items-center space-x-2"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <span className="text-sm font-medium text-gray-700">Time Range:</span>
          {["1M", "3M", "6M", "1Y", "All"].map((range) => (
            <Button
              key={range}
              variant={timeRange === range ? "default" : "outline"}
              size="sm"
              onClick={() => handleTimeRangeChange(range)}
            >
              {range}
            </Button>
          ))}
        </motion.div>

        {/* Key Performance Indicators - Empty State */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() => handleMetricChange("revenue")}
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Revenue
                </CardTitle>
                <DollarSign className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">₹0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Activity className="h-4 w-4 mr-1" />
                  Connect to view revenue
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() => handleMetricChange("exports")}
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Export Volume
                </CardTitle>
                <Package className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0 MT</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  Ready to track exports
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() => handleMetricChange("markets")}
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Active Markets
                </CardTitle>
                <Globe className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">0</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Target className="h-4 w-4 mr-1" />
                  Connect market data
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() => handleMetricChange("customers")}
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Customer Satisfaction
                </CardTitle>
                <Users className="h-4 w-4 text-gold-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">--</div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Activity className="h-4 w-4 mr-1" />
                  Setup feedback system
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Charts Section - Empty State */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Revenue Trends - Empty */}
          <motion.div
            className="lg:col-span-2"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <LineChart className="mr-2 h-5 w-5 text-green-600" />
                  Revenue & Export Trends
                </CardTitle>
                <CardDescription>
                  Revenue analytics will appear once data is connected
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      No Analytics Data
                    </h3>
                    <p className="text-gray-500 mb-4">
                      Connect your data sources to view revenue trends and
                      export performance
                    </p>
                    <Button onClick={handleSetupAnalytics}>
                      Setup Analytics
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Market Analysis - Empty */}
          <motion.div initial="initial" animate="animate" variants={fadeInUp}>
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChart className="mr-2 h-5 w-5 text-blue-600" />
                  Market Distribution
                </CardTitle>
                <CardDescription>Market analytics by region</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center">
                  <div className="text-center">
                    <PieChart className="mx-auto h-8 w-8 text-gray-400 mb-3" />
                    <p className="text-sm text-gray-500 mb-3">
                      Market data will display once exports are recorded
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => alert("Navigate to exports module")}
                    >
                      Create First Export
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Market Analysis - Empty State */}
        <motion.div initial="initial" animate="animate" variants={fadeInUp}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="mr-2 h-5 w-5 text-purple-600" />
                Market Performance Analysis
              </CardTitle>
              <CardDescription>
                Market insights will appear once export data is available
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Globe className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                <h3 className="text-xl font-medium text-gray-900 mb-2">
                  No Market Data Available
                </h3>
                <p className="text-gray-500 mb-6 max-w-md mx-auto">
                  Start exporting to different markets to see detailed analytics
                  and performance insights for each target region.
                </p>
                <div className="flex justify-center space-x-4">
                  <Button onClick={handleSetupAnalytics}>
                    <Plus className="mr-2 h-4 w-4" />
                    Setup Market Tracking
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => alert("View market guide")}
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    Market Guide
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Advanced Analytics Features */}
        <motion.div initial="initial" animate="animate" variants={fadeInUp}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Advanced Analytics Tools</CardTitle>
              <CardDescription>
                AI-powered insights and predictive analytics (Coming Soon)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div
                  className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg cursor-pointer hover:from-blue-100 hover:to-blue-200 transition-colors"
                  onClick={() =>
                    alert(
                      "🤖 Predictive Analytics\n\nAI-powered forecasting:\n\n• Market demand prediction\n• Price trend analysis\n• Seasonal pattern recognition\n• Risk assessment\n• Optimal export timing\n• Customer behavior prediction\n\nComing soon - Connect your data sources to enable these features",
                    )
                  }
                >
                  <h4 className="font-semibold text-blue-900 mb-2">
                    🤖 Predictive Analytics
                  </h4>
                  <p className="text-sm text-blue-700">
                    AI-powered market forecasting and trend prediction
                  </p>
                  <Badge className="mt-2" variant="secondary">
                    Coming Soon
                  </Badge>
                </div>

                <div
                  className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg cursor-pointer hover:from-green-100 hover:to-green-200 transition-colors"
                  onClick={() =>
                    alert(
                      "📈 Performance Intelligence\n\nComprehensive KPI tracking:\n\n• Export efficiency metrics\n• Profit margin analysis\n• Customer lifetime value\n• Market penetration rates\n• Competitive positioning\n• ROI optimization\n\nSetup your performance dashboard to get started",
                    )
                  }
                >
                  <h4 className="font-semibold text-green-900 mb-2">
                    📈 Performance Intelligence
                  </h4>
                  <p className="text-sm text-green-700">
                    Real-time KPI monitoring and performance optimization
                  </p>
                  <Badge className="mt-2" variant="secondary">
                    Setup Required
                  </Badge>
                </div>

                <div
                  className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg cursor-pointer hover:from-purple-100 hover:to-purple-200 transition-colors"
                  onClick={() =>
                    alert(
                      "🎯 Market Intelligence\n\nDeep market insights:\n\n• Competitor analysis\n• Market opportunities\n• Customer segmentation\n• Pricing optimization\n• Demand forecasting\n• Risk assessment\n\nConnect market data sources to unlock these insights",
                    )
                  }
                >
                  <h4 className="font-semibold text-purple-900 mb-2">
                    🎯 Market Intelligence
                  </h4>
                  <p className="text-sm text-purple-700">
                    Competitive analysis and market opportunity identification
                  </p>
                  <Badge className="mt-2" variant="secondary">
                    Ready to Setup
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Getting Started */}
        <motion.div initial="initial" animate="animate" variants={fadeInUp}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Get Started with Analytics</CardTitle>
              <CardDescription>
                Follow these steps to set up your business intelligence platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center p-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Database className="h-6 w-6 text-blue-600" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">
                    Connect Data
                  </h4>
                  <p className="text-sm text-gray-600">
                    Link your export, financial, and customer data sources
                  </p>
                </div>
                <div className="text-center p-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Target className="h-6 w-6 text-green-600" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">
                    Define KPIs
                  </h4>
                  <p className="text-sm text-gray-600">
                    Set up key performance indicators and business metrics
                  </p>
                </div>
                <div className="text-center p-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <BarChart3 className="h-6 w-6 text-purple-600" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">
                    Build Dashboards
                  </h4>
                  <p className="text-sm text-gray-600">
                    Create custom dashboards for different stakeholders
                  </p>
                </div>
                <div className="text-center p-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Calendar className="h-6 w-6 text-orange-600" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">
                    Schedule Reports
                  </h4>
                  <p className="text-sm text-gray-600">
                    Set up automated reporting and alert notifications
                  </p>
                </div>
              </div>
              <div className="mt-6 text-center">
                <Button
                  onClick={handleSetupAnalytics}
                  className="bg-purple-600 text-white hover:bg-purple-700"
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Start Setup Wizard
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
