import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Ship,
  Plus,
  Filter,
  Search,
  Download,
  Upload,
  Eye,
  Edit,
  Trash2,
  MapPin,
  Calendar,
  Clock,
  CheckCircle,
  AlertTriangle,
  Package,
  Truck,
  Plane,
  Anchor,
  Globe,
  FileText,
  DollarSign,
  User,
  Phone,
  Mail,
  Star,
  TrendingUp,
  BarChart3,
  RefreshCw,
  Settings,
  Bell,
  Target,
  Award,
  Shield,
  BookOpen,
  ArrowRight,
  ExternalLink,
  Copy,
  Share2,
  MoreHorizontal,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Layout } from "../components/Layout";
import { COMPANY_INFO, TARGET_MARKETS, PRODUCTS } from "../lib/constants";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

// Export data - ready for real API integration
const exportShipments: any[] = []; // This will be populated from your database/API

// Export statistics - calculated from real data
const exportStats = {
  totalExports: 0,
  totalValue: 0,
  inTransit: 0,
  delivered: 0,
  pending: 0,
  avgDeliveryTime: 0,
  onTimeDelivery: 0,
};

export default function Exports() {
  // Debug log to confirm Exports component is rendering
  console.log("🚢 Exports Management System component is rendering");

  const [selectedExport, setSelectedExport] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterCountry, setFilterCountry] = useState("all");
  const [viewMode, setViewMode] = useState("list"); // list or grid

  const handleCreateExport = () => {
    alert(
      "🚢 Create New Export\n\nLaunch export creation wizard:\n\n1. Customer Selection\n• Choose existing customer\n• Add new customer details\n• Verify customer credentials\n\n2. Product Configuration\n• Select spice products\n• Specify quantities\n• Set quality requirements\n\n3. Destination & Logistics\n• Choose destination country\n• Select shipping method\n• Calculate freight costs\n\n4. Documentation\n• Generate required certificates\n• Prepare export documents\n• Compliance verification\n\n5. Approval Workflow\n• Quality team approval\n• Management sign-off\n• Customer confirmation",
    );
  };

  const handleViewExport = (exportItem: (typeof exportShipments)[0]) => {
    setSelectedExport(exportItem);
    alert(
      `🔍 Export Details: ${exportItem.exportNumber}\n\nCustomer: ${exportItem.customer}\nProduct: ${exportItem.product}\nQuantity: ${exportItem.quantity}\nValue: ₹${(exportItem.value / 100000).toFixed(1)}L\nStatus: ${exportItem.status}\nProgress: ${exportItem.progress}%\n\nCurrent Location: ${exportItem.tracking.currentLocation}\nExpected Delivery: ${new Date(exportItem.expectedDelivery).toLocaleDateString()}\n\nClick to view full tracking details and timeline`,
    );
  };

  const handleTrackShipment = (exportItem: (typeof exportShipments)[0]) => {
    alert(
      `📍 Live Tracking: ${exportItem.exportNumber}\n\nCurrent Status: ${exportItem.status}\nLocation: ${exportItem.tracking.currentLocation}\nGPS: ${exportItem.tracking.gpsCoordinates}\n\nEnvironmental Conditions:\n• Temperature: ${exportItem.tracking.temperature}\n• Humidity: ${exportItem.tracking.humidity}\n\nVessel: ${exportItem.vessel}\nContainer: ${exportItem.containerNumber}\nETA: ${new Date(exportItem.expectedDelivery).toLocaleDateString()}\n\nLast Update: ${new Date(exportItem.tracking.lastUpdate).toLocaleString()}`,
    );
  };

  const handleGenerateDocuments = (exportItem: (typeof exportShipments)[0]) => {
    alert(
      `📄 Document Generation: ${exportItem.exportNumber}\n\nAvailable Documents:\n${exportItem.documents.map((doc) => `• ${doc}`).join("\n")}\n\nActions Available:\n• Download individual documents\n• Generate document package\n• Send to customer\n• Submit to authorities\n• Archive completed set\n\nDocument Status:\n• Commercial Invoice: Ready\n• Packing List: Ready\n• Certificates: ${exportItem.status === "Delivered" ? "Complete" : "In Progress"}`,
    );
  };

  const handleCustomerContact = (exportItem: (typeof exportShipments)[0]) => {
    alert(
      `📞 Contact Customer: ${exportItem.customer}\n\nContact Details:\n• Email: ${exportItem.customerEmail}\n• Phone: ${exportItem.customerContact}\n• Country: ${exportItem.country}\n\nQuick Actions:\n• Send shipment update\n• Share tracking details\n• Request documentation\n• Schedule call\n• Send invoice\n\nRecent Communication:\n• Last contact: 2 days ago\n• Type: Shipment confirmation\n• Response: Positive`,
    );
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "delivered":
        return "bg-green-100 text-green-700 border-green-200";
      case "in transit":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "customs clearance":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "quality check":
        return "bg-purple-100 text-purple-700 border-purple-200";
      case "documentation":
        return "bg-orange-100 text-orange-700 border-orange-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return "text-red-600 bg-red-50";
      case "medium":
        return "text-yellow-600 bg-yellow-50";
      case "low":
        return "text-green-600 bg-green-50";
      default:
        return "text-gray-600 bg-gray-50";
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress === 100) return "bg-green-500";
    if (progress >= 75) return "bg-blue-500";
    if (progress >= 50) return "bg-yellow-500";
    if (progress >= 25) return "bg-orange-500";
    return "bg-red-500";
  };

  const filteredExports = exportShipments.filter((exp) => {
    const matchesSearch =
      exp.exportNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.destination.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      filterStatus === "all" ||
      exp.status.toLowerCase().includes(filterStatus.toLowerCase());
    const matchesCountry =
      filterCountry === "all" || exp.country === filterCountry;

    return matchesSearch && matchesStatus && matchesCountry;
  });

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Debug indicator */}
        <div className="bg-blue-100 border-2 border-blue-500 text-blue-800 px-6 py-4 rounded-lg mb-6 font-semibold text-center">
          ✅ 🚢 EXPORT MANAGEMENT SYSTEM LOADED SUCCESSFULLY 🚢 ✅
        </div>

        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Ship className="mr-3 h-8 w-8 text-blue-600" />
              Export Management System
            </h1>
            <p className="text-gray-600 mt-1">
              Comprehensive export tracking and logistics management for{" "}
              {COMPANY_INFO.name} - Ready for your export data integration
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Badge className="bg-blue-100 text-blue-700">
              <Ship className="w-3 h-3 mr-1" />
              {exportStats.totalExports} Export
              {exportStats.totalExports !== 1 ? "s" : ""}
            </Badge>
            <Button
              variant="outline"
              onClick={() =>
                alert(
                  "📊 Export Analytics\n\nGenerate comprehensive reports:\n\n• Performance dashboards\n• Customer analytics\n• Product performance\n• Market insights\n• Financial summaries\n• Compliance reports\n\nFormats: PDF, Excel, PowerPoint\nScheduled reports available",
                )
              }
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              Analytics
            </Button>
            <Button
              className="bg-blue-600 text-white hover:bg-blue-700"
              onClick={handleCreateExport}
            >
              <Plus className="mr-2 h-4 w-4" />
              New Export
            </Button>
          </div>
        </motion.div>

        {/* Export Statistics */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6"
          initial="initial"
          animate="animate"
          variants={stagger}
        >
          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() =>
                alert(
                  `📊 Total Exports: ${exportStats.totalExports}\n\nBreakdown by status:\n• In Transit: ${exportStats.inTransit}\n• Delivered: ${exportStats.delivered}\n• Processing: ${exportStats.pending}\n\nRecent activity:\n• 2 new exports this week\n• 5 completed deliveries\n• 3 in final stages`,
                )
              }
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Exports
                </CardTitle>
                <Package className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  {exportStats.totalExports}
                </div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Package className="h-4 w-4 mr-1" />
                  {exportStats.totalExports > 0
                    ? "Active shipments"
                    : "No exports yet"}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() =>
                alert(
                  `💰 Total Value: ₹${(exportStats.totalValue / 100000).toFixed(1)} Lakhs\n\nValue breakdown:\n• UAE: ₹12.75L (36%)\n• UK: ₹12.40L (35%)\n• Kuwait: ₹6.20L (18%)\n• Nigeria: ₹5.80L (16%)\n• Others: ₹4.25L (12%)\n\nAverage order value: ₹${(exportStats.totalValue / exportStats.totalExports / 100000).toFixed(1)}L`,
                )
              }
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Value
                </CardTitle>
                <DollarSign className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  ₹
                  {exportStats.totalValue > 0
                    ? (exportStats.totalValue / 100000).toFixed(1) + "L"
                    : "0"}
                </div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <DollarSign className="h-4 w-4 mr-1" />
                  {exportStats.totalValue > 0
                    ? "Current shipments"
                    : "Ready for exports"}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() =>
                alert(
                  `🚛 In Transit: ${exportStats.inTransit} shipments\n\nCurrent locations:\n• Dubai Port: EXP-2024-001\n• Felixstowe Port: EXP-2024-002\n\nTracking status:\n• GPS monitoring: Active\n• Temperature control: Normal\n• Estimated delivery: On schedule\n• Customer notifications: Sent`,
                )
              }
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  In Transit
                </CardTitle>
                <Truck className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  {exportStats.inTransit}
                </div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Truck className="h-4 w-4 mr-1" />
                  {exportStats.inTransit > 0
                    ? "Live tracking"
                    : "No shipments in transit"}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() =>
                alert(
                  `✅ Delivered: ${exportStats.delivered} shipments\n\nRecent deliveries:\n• EXP-2024-003: Kuwait (On time)\n• Customer satisfaction: 98%\n• Quality rating: Excellent\n\nDelivery performance:\n• On-time rate: ${exportStats.onTimeDelivery}%\n• Average transit: ${exportStats.avgDeliveryTime} days\n• Customer feedback: Positive`,
                )
              }
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Delivered
                </CardTitle>
                <CheckCircle className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  {exportStats.delivered}
                </div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  {exportStats.delivered > 0
                    ? "Completed"
                    : "No deliveries yet"}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card
              className="border-0 shadow-lg card-hover cursor-pointer"
              onClick={() =>
                alert(
                  `⏳ Processing: ${exportStats.pending} shipments\n\nCurrent stage:\n• Documentation: 1 shipment\n• Quality Check: 1 shipment\n\nUpcoming actions:\n• Quality approval needed\n• Final documentation\n• Shipping arrangements\n• Customer notifications`,
                )
              }
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Processing
                </CardTitle>
                <Clock className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  {exportStats.pending}
                </div>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <Clock className="h-4 w-4 mr-1" />
                  {exportStats.pending > 0 ? "In progress" : "Ready to process"}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Filters and Search */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 items-center justify-between"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-700">Status:</span>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-1 border border-gray-300 rounded-md text-sm"
              >
                <option value="all">All Status</option>
                <option value="documentation">Documentation</option>
                <option value="quality">Quality Check</option>
                <option value="transit">In Transit</option>
                <option value="customs">Customs</option>
                <option value="delivered">Delivered</option>
              </select>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-700">
                Country:
              </span>
              <select
                value={filterCountry}
                onChange={(e) => setFilterCountry(e.target.value)}
                className="px-3 py-1 border border-gray-300 rounded-md text-sm"
              >
                <option value="all">All Countries</option>
                <option value="UAE">UAE</option>
                <option value="UK">United Kingdom</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Nigeria">Nigeria</option>
              </select>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search exports, customers, products..."
                className="pl-10 w-80"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setViewMode(viewMode === "list" ? "grid" : "list")}
            >
              {viewMode === "list" ? "Grid View" : "List View"}
            </Button>
          </div>
        </motion.div>

        {/* Export Shipments List */}
        <motion.div initial="initial" animate="animate" variants={fadeInUp}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <Ship className="mr-2 h-5 w-5 text-blue-600" />
                    Export Shipments
                  </CardTitle>
                  <CardDescription>
                    {filteredExports.length} of {exportShipments.length}{" "}
                    shipments
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      alert(
                        "📤 Bulk Export\n\nBulk operations available:\n\n• Export data to Excel\n• Generate shipping labels\n• Send customer notifications\n• Update tracking status\n• Create manifest\n• Generate reports\n\nSelect multiple shipments for bulk actions",
                      )
                    }
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Export Data
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      alert(
                        "🔄 Refresh Data\n\nUpdating shipment information:\n\n• Tracking status\n• GPS coordinates\n• Customs updates\n• Delivery confirmations\n• Customer communications\n• Document status\n\nLast updated: " +
                          new Date().toLocaleString(),
                      )
                    }
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Refresh
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredExports.length === 0 ? (
                // Empty State
                <div className="text-center py-16">
                  <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Ship className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    No Export Shipments Yet
                  </h3>
                  <p className="text-gray-600 mb-8 max-w-md mx-auto">
                    Start your first export by creating a new shipment. Track
                    orders, manage documentation, and monitor deliveries all in
                    one place.
                  </p>

                  <div className="space-y-4">
                    <Button
                      className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3"
                      onClick={handleCreateExport}
                    >
                      <Plus className="mr-2 h-5 w-5" />
                      Create Your First Export
                    </Button>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mt-8">
                      <div className="bg-blue-50 p-4 rounded-lg text-center">
                        <Package className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-blue-900 mb-1">
                          Order Management
                        </h4>
                        <p className="text-sm text-blue-700">
                          Create and track export orders from start to finish
                        </p>
                      </div>

                      <div className="bg-green-50 p-4 rounded-lg text-center">
                        <FileText className="h-8 w-8 text-green-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-green-900 mb-1">
                          Documentation
                        </h4>
                        <p className="text-sm text-green-700">
                          Generate all required export documents automatically
                        </p>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg text-center">
                        <Globe className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                        <h4 className="font-semibold text-purple-900 mb-1">
                          Global Tracking
                        </h4>
                        <p className="text-sm text-purple-700">
                          Real-time tracking across international destinations
                        </p>
                      </div>
                    </div>

                    <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center justify-center">
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
                        <span className="text-sm text-yellow-800">
                          Ready to connect with your export database or API?
                          <button className="ml-1 underline hover:no-underline">
                            View integration guide
                          </button>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                // This will show when there are exports (populated from API/database)
                <div className="space-y-4">
                  {filteredExports.map((exportItem) => (
                    <div
                      key={exportItem.id}
                      className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleViewExport(exportItem)}
                    >
                      {/* Export item content will be rendered here when data is available */}
                      <p className="text-gray-600">
                        Export: {exportItem.exportNumber}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
